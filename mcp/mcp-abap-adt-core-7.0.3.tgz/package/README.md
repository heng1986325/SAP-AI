# <img src="logo.png" alt="mcp-abap-adt logo" width="36" align="absmiddle" /> mcp-abap-adt: Your Gateway to ABAP Development Tools (ADT)
[![Stand With Ukraine](https://raw.githubusercontent.com/vshymanskyy/StandWithUkraine/main/badges/StandWithUkraine.svg)](https://stand-with-ukraine.pp.ua)

**English** | [中文](README.zh-CN.md)

`mcp-abap-adt` is an MCP server for ABAP ADT in SAP ECC/S/4HANA (on-premise) and SAP BTP ABAP Cloud systems. It gives agents controlled access to real ABAP repositories through ADT, so analysis and changes are grounded in system data instead of assumptions. It is built for AI-assisted pair programming (AIPNV: AI Pairing, Not Vibing), not autopilot vibe coding.

**Primary workflows:**
- **Deep ABAP analysis**: where-used, object metadata, repository navigation, object structure, semantic analysis, dependency and impact exploration.
- **High-level ABAP development**: rapid CRUD and iterative updates for RAP and classic ABAP artifacts (classes, interfaces, function groups/modules, programs, DDIC, CDS/view/service artifacts), validated through ADT flows.

**Why teams use it:**
- **Full CRUD** (not read-only): create, read, update, and delete ABAP artifacts
- Works with **On-Premise (ECC/S/4HANA)**, **ABAP Cloud (BTP)**, and **Legacy** systems (BASIS < 7.50)
- **JWT/XSUAA**, **service key** (destination-based), and **RFC** authorization
- **S/4HANA Cloud browser SSO**: [Reentrance Ticket login](docs/user-guide/REENTRANCE_TICKET_ZH.md) over stdio, HTTP, or SSE, with lazy sign-in and isolated in-memory SAP sessions
- Multiple transports: **stdio**, **HTTP**, **SSE**
- Rich tool surface for ABAP objects, metadata, transports, and search

**Authorization & Destinations (Important):** A *destination* is the filename of a service key stored locally. You place service keys in the service-keys directory, and use `--mcp=<destination>` to select which one to use. This is the primary auth model for on‑prem and BTP systems. See [Authentication & Destinations](docs/user-guide/AUTHENTICATION.md).

You can configure MCP clients either manually (JSON/TOML) or via the configurator CLI (`@mcp-abap-adt/configurator`, repo: [`mcp-abap-adt-conf`](https://github.com/fr0ster/mcp-abap-adt-conf)).

## Table of Contents

1. [Getting Started](#getting-started)
   - [Where the package comes from](#where-the-package-comes-from)
   - [Method 0 — Hi platform (`hi` CLI), no registration step](#installation-method-0-hi-platform-hi-cli)
   - [Method 1 — Global install (recommended)](#installation-method-1-global-install-recommended)
   - [Method 2 — Project-scoped install](#installation-method-2-project-scoped-install)
   - [Method 3 (other) — standalone HTTP / SSE](#installation-method-3-other--standalone-http--sse-advanced)
   - [Updating the MCP](#updating-the-mcp)
2. [Connecting to Multiple Systems & Switching](#connecting-to-multiple-systems--switching)
3. [.env File Reference](#env-file-reference)
4. [Architecture](#architecture)
5. [Quick Start](#quick-start)
6. [Use Cases](#use-cases)
7. [Target Users](#target-users)
8. [Capabilities (High-Level Focus)](#capabilities-high-level-focus)
9. [Terminology](#terminology)
10. [Authorization & Destinations](#authorization--destinations)
11. [Registries](#registries)
12. [Tools Overview](#tools-overview)
13. [Documentation](#documentation)
14. [Dependencies](#dependencies)
15. [Running the Server](#running-the-server)
16. [Changelog & Enhancements](#changelog--enhancements)

## Getting Started

> **Installing for S/4HANA / ECC on‑premise? This is the standard path.** You do **not** start the server yourself, and you do **not** use the server's HTTP mode (that is [installation method 3](#installation-method-3-other--standalone-http--sse-advanced), for standalone/remote deployments only): your MCP client (e.g. Claude Code) launches the server as a local **stdio** process automatically.

Pick an install: **[method 0 — Hi platform](#installation-method-0-hi-platform-hi-cli)** (fewest steps, if your company publishes it there), **[method 1 — global install](#installation-method-1-global-install-recommended)** (shared by all projects) or **[method 2 — project‑scoped install](#installation-method-2-project-scoped-install)** (config travels with the project). To connect several systems see [Connecting to Multiple Systems & Switching](#connecting-to-multiple-systems--switching); for env fields and other auth types see the [.env File Reference](#env-file-reference).

### Prerequisites

- Node.js ≥ 22 (locally verified with v24)
- The target SAP system exposes the ADT services (SICF node `/sap/bc/adt` active) and your user has the corresponding ADT authorizations
- Write operations (Create/Update/Delete/Activate) require the matching `S_DEVELOP` authorizations
- One of the package sources below, with its CLI installed and authenticated

### Where the package comes from

The published package carries the [added tools](#changelog--enhancements) that are not in the npm
release, and ships `dist/` prebuilt — **no build step** on any of these paths. Three sources, and
**they differ in whether dependencies and registration come with it**:

| Source | Dependencies | Registration | Then read |
|---|---|---|---|
| **Hi platform** (`hi` CLI) | **included** | **automatic** | [method 0](#installation-method-0-hi-platform-hi-cli) |
| **Feishu bundle** (`lark-cli`) | you install them | you run a script | [method 1](#installation-method-1-global-install-recommended) / [2](#installation-method-2-project-scoped-install) |
| **git clone** | you install them **and build** | you run a script | [below](#installing-from-source-git-clone) |

#### Feishu bundle

`install-skills.mjs` is **not installed globally** — fetch it fresh (it self‑updates), then run it
**from whatever directory you downloaded it into**:

```bash
node install-skills.mjs --skill mcp-abap-adt   # re-run any time to update
```

> **The installer asks where to put the copy — local or global — and prints the final install path.** *Global* places it under your home directory (`~/.mcp/mcp-abap-adt`); *local* places it in the current directory. Note the path it reports: every later step runs from **inside that unpacked copy**.

**Then install the runtime dependencies.** The Feishu publisher cannot carry `node_modules`, so the
bundle arrives without it and **the server will not start until you run this once inside that
unpacked copy**:

```bash
npm install --omit=dev --ignore-scripts
```

(`--ignore-scripts` skips lifecycle hooks belonging to devDependencies such as husky, which cannot
succeed under `--omit=dev`. Passing `--install-deps` to `install-skills.mjs` in the previous step does
this for you. A side effect: `kerberos`'s native binary is not downloaded either, so Kerberos auth
is unavailable on a copy installed this way — drop `--ignore-scripts` and reinstall if you need it,
which requires a local build toolchain.)

#### Installing from source (git clone)

`dist/` is not in version control, so a clone must be built, and the build needs devDependencies —
do **not** pass `--omit=dev` here. This is the opposite of the bundle above:

```bash
npm install          # full install, devDependencies included
npm run build        # biome + tsc, then prunes orphaned dist artifacts
npm prune --omit=dev # optional: drop dev deps once dist/ exists
```

Registration does not have to go through `scripts/install-mcp.js`; Claude Code's own CLI works, with
absolute paths:

```bash
claude mcp add adt-dm2 -s user -e NODE_TLS_REJECT_UNAUTHORIZED=0 \
  -- node /abs/path/to/mcp-abap-adt/bin/mcp-abap-adt.js \
     --env-path=/abs/path/to/dm2310.env --exposition=readonly,high
```

### Installation method 0: Hi platform (`hi` CLI)

**If your company publishes this server as a Hi asset, this is the shortest path: one command
installs it, writes the client configuration and brings its dependencies with it.** There is no
`npm install` and no `install-mcp.js` step — the package carries its own `node_modules`, and `hi`
writes the server entry into the directory's `.mcp.json` (and `.codex/config.toml`) itself.

**① Log in and pick the project** that the asset is granted to:

```bash
hi whoami --json                 # confirms login, company and device
hi project list --json           # the projects you can use
hi project use <PROJECT_CODE>    # associates the CURRENT directory
```

**② Install into the directory you work in.** Always pass `--root` as an absolute path rather than
relying on the current directory:

```bash
hi project init --root /abs/path/to/your/project --json
```

This unpacks the server to `<root>/.hi/mcp/mcp-abap-adt/<version>/` and registers it. Add `.hi/`,
`.hi-pack/` and `.mcp.json` to that project's `.gitignore` — all three are machine-local, and
`.mcp.json` holds absolute paths **including the installed version directory**, so it goes stale as
soon as anyone publishes.

**③ Fill in the credentials.** On first install `hi` seeds `<root>/.hi/mcp/mcp-abap-adt/.env` from
the package's `.env.example`, **keeping the comments and public defaults but blanking the user and
password**. Nothing is uploaded and nothing is filled in for you:

```bash
hi mcp doctor --json    # names the required variables that are still empty
```

Edit that `.env`, then **restart your MCP client**. See the [.env File Reference](#env-file-reference)
for the fields.

**④ Check what you have:**

```bash
hi mcp list --json      # installed servers and their versions
hi mcp doctor --json    # ledger / .mcp.json / local store consistency
```

> **Kerberos is not usable from this package.** Its dependencies are installed with
> `--ignore-scripts`, so `kerberos`'s native binary is never downloaded and the package stays
> platform-neutral. Use basic, JWT or certificate auth here, or install from source for Kerberos.

### Installation method 1: Global install (recommended)

The env file lives in the standard sessions directory and the server entry is registered in the user‑scoped `~/.claude.json`, so **all projects share the same server**.

**① Register globally.** Change into the unpacked copy — the path the installer printed above — then register. If you chose a **global** install the copy is under your home dir; use the `cd` form for your shell:

```bash
# macOS / Linux / Git Bash / WSL, and Windows PowerShell (all expand ~):
cd ~/.mcp/mcp-abap-adt

# Windows PowerShell (explicit, if ~ is not expanded):
cd $env:USERPROFILE\.mcp\mcp-abap-adt

# Windows cmd.exe (~ is NOT expanded here):
cd /d %USERPROFILE%\.mcp\mcp-abap-adt
```

Then register:

```bash
node scripts/install-mcp.js --global --name=dev
```

The script copies an env template into the standard sessions directory and registers the server as a **stdio** entry (backed up first), filling in the absolute path to `bin/mcp-abap-adt.js` automatically. The entry references the env by name with `--env=dev`:

```json
"adt-dev": {
  "command": "node",
  "args": [
    "<absolute-path-to-the-copy>/bin/mcp-abap-adt.js",
    "--env=dev",
    "--exposition=readonly,high"
  ],
  "env": { "NODE_TLS_REJECT_UNAUTHORIZED": "0" }
}
```

**Both Claude Code and Codex are registered by default.** The script writes the entry to `~/.claude.json` (Claude Code) and — when Codex is detected (`~/.codex/` exists) — the equivalent `[mcp_servers.adt-dev]` block to `~/.codex/config.toml` (both backed up first). Codex uses the same `--env=dev` (resolved to the sessions directory, so it works regardless of Codex's working directory). Control it with `--codex` (force even if `~/.codex` is absent) or `--no-codex` (skip). After installing, **restart the client** (both read config only at startup).

**② Edit the env file (by file path).** It is in the standard sessions directory:
- Unix: `~/.config/mcp-abap-adt/sessions/dev.env`
- Windows: `%USERPROFILE%\Documents\mcp-abap-adt\sessions\dev.env`

Fill in real connection data (**holds credentials — never commit**). Fields and other auth types are in the [.env File Reference](#env-file-reference):

```bash
SAP_URL=http://your-sap-host:8000
SAP_CLIENT=100
SAP_LANGUAGE=en
SAP_SYSTEM_TYPE=onprem
SAP_CONNECTION_TYPE=http
SAP_AUTH_TYPE=basic
SAP_USERNAME=YOUR_USER
SAP_PASSWORD=your-password
NODE_TLS_REJECT_UNAUTHORIZED=0
```

**③ Restart your MCP client and verify.** Config is read only at client startup; restart Claude Code and it spawns the server over stdio — the ABAP tools appear (nothing to launch manually). Run a read‑only tool (e.g. `SearchObject`) to confirm the connection and authorizations.

### Installation method 2: Project-scoped install

The env file and `.mcp.json` live **inside one project**, so the config travels with the project — good when a project is tied to one system.

**① Register into the project** (run from the unpacked copy; `--target` points at the project):

```bash
node scripts/install-mcp.js --target=/path/to/my-abap-project --name=dev
```

The script writes `env/dev.env` and `.mcp.json` inside the project (merges into an existing `.mcp.json`; never overwrites an env file). The entry references the env by path with `--env-path` (project‑relative):

```json
"adt-dev": {
  "command": "node",
  "args": [
    "<absolute-path-to-the-copy>/bin/mcp-abap-adt.js",
    "--env-path=env/dev.env",
    "--exposition=readonly,high"
  ],
  "env": { "NODE_TLS_REJECT_UNAUTHORIZED": "0" }
}
```

> **Path rules:** the first `args` entry (bin path) must be an **absolute path**; a relative `--env-path` resolves against the working directory the client starts the server in (for Claude Code: the project root). Add the project's `env/` to `.gitignore` (it holds credentials). You can also write the JSON above into the project's `.mcp.json` by hand instead of using the script.

> **Codex (project install):** Codex has no per-project config — its MCP servers live in the global `~/.codex/config.toml`. So the script also registers `[mcp_servers.adt-dev]` there (when Codex is detected), but with an **absolute** `--env-path` to the project's env file (a project-relative path wouldn't resolve, since Codex doesn't run the server from the project dir). Use `--no-codex` to skip.

**② Edit the env file (by file path):** `env/dev.env` inside the project — fields in the [.env File Reference](#env-file-reference).

**③ Restart your MCP client and verify** (same as method 1, step ③).

> Other clients (Cline / Copilot, …) can be auto-configured with `mcp-conf`: see upstream [CLIENT_INSTALLERS.md](https://github.com/fr0ster/mcp-abap-adt-conf/tree/main/docs/CLIENT_INSTALLERS.md).

### Installation method 3 (other) — standalone HTTP / SSE (advanced)

**A normal install does not use this.** Only when the server must run as a long‑lived standalone service that remote clients reach over HTTP/SSE (it is then *not* spawned via MCP‑client stdio). You can also run the stdio command once by hand for debugging. See [Running the Server](#running-the-server) for the full option list.

```bash
# HTTP mode (default port 3000)
node bin/mcp-abap-adt.js --transport=http --http-port=8080

# SSE mode
node bin/mcp-abap-adt.js --transport=sse --sse-port=3001

# stdio by hand (debugging only; normal integration spawns it for you)
node bin/mcp-abap-adt.js --transport=stdio --env-path=/path/to/my.env
```

### Updating the MCP

**Every path is: re-fetch, then restart the client.** The server loads `dist/` at startup, so a
running process keeps serving the old code until it is restarted — a rebuild or re-install is
invisible to it. Use the command for the source you installed from:

```bash
# Hi platform — re-run init; it updates in place and rewrites .mcp.json
hi project init --root /abs/path/to/your/project --json

# Feishu bundle — run install-skills.mjs from its own directory and pick the
# SAME install location as before, so it overwrites the existing copy (dist/ included)
node install-skills.mjs --skill mcp-abap-adt

# git clone
git pull && npm install && npm run build
```

**Then restart your MCP client (Claude Code).** After restarting, run a read‑only tool to confirm —
`GetSession` is the one to use, because it reports the build that actually answered:

```
server_version    7.0.3
build_timestamp   the build LOADED, not the file currently on disk
started_at        process start
pid               which process answered
```

Registration does **not** need to be redone on any path. A Feishu or source install registers a
path, and the code at that path was just replaced; a Hi install has its `.mcp.json` rewritten by
`hi project init`. Your `.env` is left alone in every case — on the Hi path an update keeps the
values you filled in and only adds keys that are new.

## Connecting to Multiple Systems & Switching

Maintain **several env files** (one per target system) and switch between them, or register them side by side.

**1. One env file per system.** For a global install they live in the standard sessions directory (`dev.env` / `qas.env` / …); for a project install, in the project's `env/` folder. Put everything system-specific — including `SAP_SYSTEM_TYPE` and `SAP_CONNECTION_TYPE` — inside each file, so switching the file switches the whole system profile.

**2. Register one entry per system (recommended for multiple systems):** `adt-dev`, `adt-qas`, … each bound to its own env; call the tools of the one you need. Disable unused entries in the client to keep the tool list small. Run the install script once per system:

```bash
node scripts/install-mcp.js --global --name=qas             # global
node scripts/install-mcp.js --target=<project> --name=qas   # project-scoped
```

**3. Or switch a single entry in place:** change its `--env` (global) or `--env-path` (project), then **restart the MCP client** (a running server is bound to the env it started with — no restart, no change).

> **Global vs project:** shared across your projects with no repeated setup → global (`--env`, in `~/.claude.json`); project tied to one system and config that travels with the repo → project (`--env-path`, in the project's `.mcp.json`). They coexist — Claude Code loads entries from both.

Standard sessions directory:
- Unix: `~/.config/mcp-abap-adt/sessions/<name>.env`
- Windows: `%USERPROFILE%\Documents\mcp-abap-adt\sessions\<name>.env`

## .env File Reference

One `.env` file per target system (**never commit it** — it holds credentials). Only **full-line comments** (starting with `#`) are supported; inline comments are not parsed.

### Common fields

| Field | Meaning |
|---|---|
| `SAP_URL` | SAP ABAP application server address `http(s)://host:port` (use `https` when SSL is enabled) |
| `SAP_CLIENT` | Client (mandant) number, e.g. `100` |
| `SAP_LANGUAGE` | Logon language, e.g. `en`. **This becomes the ORIGINAL LANGUAGE of every object the server creates** (it is sent as `sap-language` on every request and declared as `adtcore:masterLanguage` in the payload, so the two always agree). Default `EN`. If your team creates objects in SE11/SE80 under a different logon language, set this to the same language — otherwise one package ends up holding objects with different original languages, which makes later translation messy. |
| `SAP_SYSTEM_TYPE` | `onprem` / `cloud` / `legacy` |
| `SAP_CONNECTION_TYPE` | `http` (default) or `rfc` — how the server reaches SAP; **unrelated to whether the server runs in HTTP mode** |
| `SAP_AUTH_TYPE` | `basic` / `jwt` / `certificate` / `kerberos` / [`reentrance-ticket`](docs/user-guide/REENTRANCE_TICKET_ZH.md) (stdio / HTTP / SSE) |
| `NODE_TLS_REJECT_UNAUTHORIZED` | Set `0` for self-signed certificates (trusted internal networks only) |

> **`SAP_USERNAME` case must match USR02 (usually UPPERCASE).** Login is case-insensitive, but on object creation the value is submitted verbatim as the ADT "responsible person" — a lowercase name fails `CreatePackage` with **PAK049** ("enter a valid user").

### Authentication types

**Basic (typical for on-premise):**
```bash
SAP_AUTH_TYPE=basic
SAP_USERNAME=YOUR_USER
SAP_PASSWORD=your-password
```

**JWT (SAP BTP):**
```bash
SAP_AUTH_TYPE=jwt
SAP_JWT_TOKEN=your-jwt-token
```

**Client certificate mTLS (on-prem HTTP only):** no username/password needed.
```bash
SAP_AUTH_TYPE=certificate
SAP_CERT_PATH=/path/to/client.crt      # PEM: certificate
SAP_CERT_KEY_PATH=/path/to/client.key  # PEM: private key
# Or PKCS#12 (alternative to PEM):
# SAP_CERT_PFX_PATH=/path/to/client.pfx
# SAP_CERT_PASSPHRASE=your-passphrase
```

**Kerberos / SPNEGO (on-prem HTTP only):** obtain a ticket first (`kinit`) and install the `kerberos` npm package (`npm i kerberos`).
```bash
SAP_AUTH_TYPE=kerberos
# Optional explicit SPN (default HTTP@<host>):
# SAP_KERBEROS_SPN=HTTP@mysaphost.corp.example
```

**RFC (legacy, BASIS < 7.50):** requires the SAP NW RFC SDK — see [RFC Setup Guide](docs/installation/RFC_SETUP.md).
```bash
SAP_AUTH_TYPE=basic
SAP_CONNECTION_TYPE=rfc
SAP_USERNAME=YOUR_USER
SAP_PASSWORD=your-password
```

> Certificate / Kerberos pass full unit coverage but are **not yet validated on a live system** — feedback welcome. See [Running the Server](#running-the-server) for the detailed auth notes.

### Destination (service key) mode

Drop a service key JSON into the standard directory and select it by filename (no extension) with `--mcp=<destination>`:
- Unix: `~/.config/mcp-abap-adt/service-keys/<destination>.json`
- Windows: `%USERPROFILE%\Documents\mcp-abap-adt\service-keys\<destination>.json`

```bash
mcp-abap-adt --transport=stdio --mcp=TRIAL
```

You can also generate an env from a service key: `npm install -g @mcp-abap-adt/connection`, then `mcp-auth auth -k path/to/service-key.json`.

## Terminology

**Destination**: a local service key filename. You store service keys in the standard `service-keys` directory, and pass the filename (without extension) via `--mcp=<destination>` to select which system to use.

See [docs/user-guide/TERMINOLOGY.md](docs/user-guide/TERMINOLOGY.md) for the full list.

## Authorization & Destinations

Destination-based auth is the default. Drop service keys into the standard platform folder and use the filename as your destination:

```bash
mcp-abap-adt --transport=stdio --mcp=TRIAL
```

Standard service key paths:
- Unix (Linux/macOS): `~/.config/mcp-abap-adt/service-keys/<destination>.json`
- Windows: `%USERPROFILE%\\Documents\\mcp-abap-adt\\service-keys\\<destination>.json`

For full details (paths, `.env`, direct headers), see [Authentication & Destinations](docs/user-guide/AUTHENTICATION.md).

## Architecture

The project provides two main usage patterns:

### 1. Standalone MCP Server (Default)
Run as a standalone MCP server. For normal use with an MCP client, **stdio** is the transport — and your client spawns it for you, so you don't run these commands yourself (see [Getting Started](#getting-started)). The HTTP/SSE transports are for standalone/remote deployments only:
```bash
mcp-abap-adt                           # stdio (default) — normal MCP client usage
mcp-abap-adt --transport=http          # HTTP mode  — standalone/remote deployments only
mcp-abap-adt --transport=sse           # SSE mode   — standalone/remote deployments only
```

### 2. Embeddable Server (For Integration)
Embed MCP server into existing applications (e.g., SAP CAP/CDS, Express):
```typescript
import {
  EmbeddableMcpServer,
  NoDedupStrategy, // optional: expose both Read<X> and Get<X>
} from '@mcp-abap-adt/core/server';

const server = new EmbeddableMcpServer({
  connection,              // Your AbapConnection instance
  logger,                  // Optional logger
  exposition: ['readonly', 'high'],  // Handler groups to expose
  // Default hides Read<X> when Get<X> is exposed (ReadVsGetDedupStrategy).
  // Pass NoDedupStrategy to expose both variants instead.
  // readOnlyDedupStrategy: new NoDedupStrategy(),
});
await server.connect(transport);
```

See [Handlers Management → EmbeddableMcpServer dedup strategies](docs/user-guide/HANDLERS_MANAGEMENT.md#embeddablemcpserver-dedup-strategies) for how readonly tools are deduped against high/low/compact, how to opt out with `NoDedupStrategy`, and how to plug a custom `IReadOnlyDedupStrategy` for role-based rules.

## Quick Start

1. **Install server**: See [Installation Guide](docs/installation/INSTALLATION.md)
2. **Configure client (auto)**: Use `mcp-conf` from `@mcp-abap-adt/configurator` (repo: [`mcp-abap-adt-conf`](https://github.com/fr0ster/mcp-abap-adt-conf), docs: [CLIENT_INSTALLERS.md](https://github.com/fr0ster/mcp-abap-adt-conf/tree/main/docs/CLIENT_INSTALLERS.md))
3. **Configure client (manual)**: See [Client Configuration](docs/user-guide/CLIENT_CONFIGURATION.md)
4. **Use**:
   - [Read-Only Tools](docs/user-guide/AVAILABLE_TOOLS_READONLY.md)
   - [High-Level Tools](docs/user-guide/AVAILABLE_TOOLS_HIGH.md)
   - [Low-Level Tools](docs/user-guide/AVAILABLE_TOOLS_LOW.md)
   - [Legacy System Tools](docs/user-guide/AVAILABLE_TOOLS_LEGACY.md)

## Use Cases

- **Impact analysis / where-used before changes**: map object usage and probable blast radius.
- **Dependency audit**: inspect links across classes, interfaces, DDIC, CDS/views, and RAP artifacts.
- **Migration and cleanup prep**: extract repository facts to plan refactoring or cloud-readiness work.
- **RAP and ABAP iterative development**: create/update artifacts quickly with ADT-backed operations.
- **Service scaffolding from an existing table**: `GenerateRepoObjects` stands up a complete RAP OData service (or a Fiori maintenance object) in one call, instead of creating each artifact by hand.
- **Automated documentation and RAG ingestion**: pull structured facts from ABAP systems for downstream tooling.

## Target Users

- ABAP developers and ABAP architects
- RAP developers
- Team leads and tech leads who need fast repository visibility
- Teams building RAG/agent workflows for SAP landscapes

## Capabilities (High-Level Focus)

Key examples of high-value workflows and tools:

- **Repository and impact analysis**: `GetWhereUsed`, `DescribeByList`, `GetObjectStructure`, `GetObjectInfo`, `SearchObject`, `GetPackageTree`, `GetPackageContents`
- **Code and semantic introspection**: `GetAbapAST`, `GetAbapSemanticAnalysis`, `GetIncludesList`
- **RAP development**: `CreateBehaviorDefinition`, `UpdateBehaviorDefinition`, `CreateBehaviorImplementation`, `UpdateBehaviorImplementation`, `CreateServiceDefinition`, `UpdateServiceDefinition`, `CreateMetadataExtension`, `UpdateMetadataExtension`
- **Repository generation (scaffolding)**: `GenerateRepoObjects` — generate a whole RAP OData service (or a Fiori maintenance object) from one DB table in a single call
- **CDS/View development**: `CreateView`, `UpdateView`, `GetView`, `DeleteView`
- **ABAP OO CRUD**: `CreateClass`, `UpdateClass`, `GetClass`, `DeleteClass`, `CreateInterface`, `UpdateInterface`, `GetInterface`, `DeleteInterface`
- **Function module/group CRUD**: `CreateFunctionGroup`, `UpdateFunctionGroup`, `GetFunctionGroup`, `DeleteFunctionGroup`, `CreateFunctionModule`, `UpdateFunctionModule`, `GetFunctionModule`, `DeleteFunctionModule`
- **Transport and activation support**: `CreateTransport`, `GetTransport`, `ActivateObject`

## Registries

Published in the official MCP Registry and listed on Glama.ai.

- MCP Registry: [docs/deployment/MCP_REGISTRY.md](docs/deployment/MCP_REGISTRY.md)
- Glama.ai:
  <a href="https://glama.ai/mcp/servers/@fr0ster/mcp-abap-adt">
    <img width="380" height="200" src="https://glama.ai/mcp/servers/@fr0ster/mcp-abap-adt/badge" />
  </a>

## Tools Overview

Roughly **368 tools** (241 exposed under `readonly,high`: 77 read-only + 164 high-level). Most object types carry the full lifecycle: `Create` / `Get` / `Update` / `Delete` / `Activate` / `Check`. Expand each group below for **the name and function of every method** (🆕 = added/absorbed by this fork; see [Changelog & Enhancements](#changelog--enhancements)).

<details>
<summary><b>Object CRUD & lifecycle</b></summary>

**DDIC — Domain / Data Element / Table / Structure**
- `CreateDomain` / `GetDomain` / `UpdateDomain` / `DeleteDomain` / `ActivateDomain` / `CheckDomain` — domain (data type, length, fixed values)
- `CreateDataElement` / `GetDataElement` / `UpdateDataElement` / `DeleteDataElement` / `ActivateDataElement` / `CheckDataElement` — data element (on a domain or built-in type + field labels)
- `CreateTable` / `GetTable` / `UpdateTable` / `DeleteTable` / `ActivateTable` / `CheckTable` — transparent table (fields/keys; data preview via `GetTableContents`)
- 🆕 `GetTableIndexes` / `CreateTableIndex` / `UpdateTableIndex` / `DeleteTableIndex` — secondary indexes (SE11, DDIC type `TABL/DTI`). The index and its table are activated together; `GetTableIndexes` is the only way to see a table's indexes, since `DD12L` is not exposed by the ADT Data Preview
- 🆕 `GetTableTechnicalSettings` / `SetTableTechnicalSettings` — SE13 buffering / size category / data class / change logging. Buffering is one parameter here (`fully_buffered`, `single_record`, `generic`, …) rather than SAP's two-field encoding, and the table is re-activated so the change actually takes effect
- `CreateStructure` / `GetStructure` / `UpdateStructure` / `DeleteStructure` / `ActivateStructure` / `CheckStructure` — structure (components + includes)

**Classic ABAP — Class / Interface / Program / Function**
- `CreateClass` / `GetClass` / `UpdateClass` / `DeleteClass` / `ActivateClass` / `CheckClass` — global class
- Class includes: `Get/Update/DeleteLocalDefinitions` (local definitions), `Get/Update/DeleteLocalTypes` (local types/implementations), `Get/Update/DeleteLocalMacros` (macros), `Get/Update/DeleteLocalTestClass` (local test class)
- `CreateInterface` / `GetInterface` / `UpdateInterface` / `DeleteInterface` / `ActivateInterface` / `CheckInterface` — global interface
- `CreateProgram` / `GetProgram` / `UpdateProgram` / `DeleteProgram` / `ActivateProgram` / `CheckProgram` — report program (on-prem / legacy only)
- `GetInclude` — read include source; `GetIncludesList` — recursively list includes
- `CreateFunctionGroup` / `GetFunctionGroup` / `UpdateFunctionGroup` / `DeleteFunctionGroup` / `ActivateFunctionGroup` / `CheckFunctionGroup` — function group
- `CreateFunctionModule` / `GetFunctionModule` / `UpdateFunctionModule` / `DeleteFunctionModule` / `ActivateFunctionModule` / `CheckFunctionModule` — function module

**CDS / RAP**
- `CreateView` / `GetView` / `UpdateView` / `DeleteView` / `ActivateView` / `CheckView` — CDS view (DDLS) / classic view
- `CreateMetadataExtension` / `GetMetadataExtension` / `UpdateMetadataExtension` / `DeleteMetadataExtension` / `ActivateMetadataExtension` / `CheckMetadataExtension` — metadata extension (DDLX)
- `CreateBehaviorDefinition` / `GetBehaviorDefinition` / `UpdateBehaviorDefinition` / `DeleteBehaviorDefinition` / `ActivateBehaviorDefinition` / `CheckBehaviorDefinition` — behavior definition (BDEF; Managed/Unmanaged/Abstract/Projection)
- `CreateBehaviorImplementation` / `GetBehaviorImplementation` / `UpdateBehaviorImplementation` / `DeleteBehaviorImplementation` — behavior implementation class (behavior pool)
- `CreateServiceDefinition` / `GetServiceDefinition` / `UpdateServiceDefinition` / `DeleteServiceDefinition` / `ActivateServiceDefinition` / `CheckServiceDefinition` — service definition (SRVD)
- `CreateServiceBinding` / `GetServiceBinding` / `UpdateServiceBinding` / `DeleteServiceBinding` / `ActivateServiceBinding` — service binding (SRVB; OData publish below)
- `CreateAccessControl` / `GetAccessControl` / `UpdateAccessControl` / `DeleteAccessControl` / `ActivateAccessControl` / `CheckAccessControl` 🆕 — CDS **access control** (DCL / DCLS): the authorization layer over a CDS entity (`define role … { grant select on … }`). `CreateAccessControl` takes the role source inline and activates in one call; `CheckAccessControl` can syntax-check a DRAFT before writing it

**Other repository objects 🆕**
- `CreateXslt` / `GetXslt` / `UpdateXslt` / `DeleteXslt` / `ActivateXslt` — transformation (XSLT/ST; source-based)
- `CreateMessageClass` / `GetMessageClass` / `UpdateMessageClass` / `DeleteMessageClass` — message class (MSAG). `UpdateMessageClass` is an **upsert**: messages you pass are created or overwritten, messages you omit are kept
- 🆕 `AddMessage` / `UpdateMessage` — maintain ONE message without resending the rest of the class (the current list is read from SAP, so nothing can be lost in transit). Note there is no `DeleteMessage`: removing a single message is not reachable through ADT on 7.58 — see [Known limitations](#changelog--enhancements)
- `CreateLockObject` / `GetLockObject` / `UpdateLockObject` / `DeleteLockObject` / `ActivateLockObject` — lock object (ENQU; primary table + lock mode; activation generates the ENQUEUE_/DEQUEUE_ function modules)

**Package / session / batch**
- `CreatePackage` — create a package (incl. a true top-level package); `GetPackage` — read metadata; `CheckPackage` — check; `DeletePackage` 🆕 — delete an EMPTY package (SAP's refusal reason is relayed verbatim; a package with no TADIR/TDEVC record cannot be removed via ADT and needs SE21)
- `GetPackageContents` — flat object list in a package; `GetPackageTree` — hierarchical tree (with subpackages)
- `ActivateObjects` — batch-activate any objects (e.g. domain + data element + table together)
- `GetInactiveObjects` — list inactive objects awaiting activation
- `GetSession` — obtain/reuse an ADT session (for chaining low-level ops)

</details>

<details>
<summary><b>Repository generators 🆕</b></summary>

- `GenerateRepoObjects` 🆕 — drive an SAP ADT **repository generator**: one call turns a single DB table into a complete, activated object bundle. Three generator types:
  - `uiservice` — full **RAP OData V4 UI service**: root CDS view + behavior definition + behavior pool + draft table + service projection + service definition + service binding + metadata extension
  - `webapiservice` — the same RAP stack as an **OData Web API** service (no UI specifics, no draft table)
  - `smbc` — **Fiori-based maintenance object** for a customizing table (SM30/SM34 replacement)
- Key parameters: `type`, `reference_object_name` (source table), `package`, plus per-type names (`cds_name`, `behavior_implementation_class`, `service_projection_name`, `service_definition_name`, `service_binding_name`, `draft_table`, `maintenance_object_name`); optional `transport_request`, `master_language`, `description`, `service_binding_type` (`OData V4 - UI` / `OData V4` / `OData V2 - UI` / `OData V2`).
- Returns the list of generated object references; for `uiservice` / `webapiservice` the created **service binding is fetched back** and returned alongside, so the binding's state is verified in the same call. Publish it with `PublishServiceBinding`.

</details>

<details>
<summary><b>Search, navigation & analysis</b></summary>

- `SearchObject` — search objects by name/wildcard
- `SearchSource` — full-text source search
- `GetWhereUsed` — where-used / impact analysis
- `DescribeByList` — batch object metadata
- `GetObjectStructure` — object structure (methods/attributes/components); `GetObjectInfo` — basic metadata
- `GetObjectsList` — list objects; `GetObjectsByType` — list by object type
- `GetTransaction` — transaction code info
- `GetEnhancements` — enhancements of an object; `GetEnhancementImpl` — implementation source; `GetEnhancementSpot` — enhancement spot
- `GetAbapAST` — abstract syntax tree; `GetAbapSemanticAnalysis` — semantic analysis; `GetAbapSystemSymbols` — system symbols
- `GetTypeInfo` — type info; `GetAdtTypes` — ADT object-type catalog
- `GetObjectRevisions` 🆕 — object version history (version/author/date)
- `GetAbapDocumentation` 🆕 — ABAP keyword/element docs (HTML) for a source position
- Low-level nav: `GetNodeStructureLow`, `GetObjectStructureLow`, `GetVirtualFoldersLow`, `GetObjectNodeFromCache`

</details>

<details>
<summary><b>Quality & testing</b></summary>

- Syntax check: per-object `Check<Object>` (see above, e.g. `CheckClass` / `CheckView`)
- `RunAtc` 🆕 — one-shot ATC (variant→worklist→run→findings with `quickfix_info`/`link`/`location`), multi-object in one run, returns `worklist_id`
- `GetAtcWorklist` 🆕 — re-read findings by `worklist_id` (no re-run); `GetAtcCustomizing` 🆕 — default variant & exemption reasons
- `GetFixProposals` 🆕 — quick-fix proposals at a position; `GetFixEdits` 🆕 — compute the edit deltas (does not write)
- ABAP Unit: `CreateUnitTest` / `GetUnitTest` / `UpdateUnitTest` / `DeleteUnitTest`, `RunUnitTest` / `GetUnitTestResult` / `GetUnitTestStatus`
- CDS tests: `CreateCdsUnitTest` / `GetCdsUnitTest` / `UpdateCdsUnitTest` / `DeleteCdsUnitTest`, `GetCdsUnitTestResult` / `GetCdsUnitTestStatus`

</details>

<details>
<summary><b>Source formatting 🆕</b></summary>

- `PrettyPrintSource` 🆕 — format source via the system pretty printer
- `GetPrettyPrinterSettings` 🆕 — read pretty-printer settings (indentation, keyword case)
- `SetPrettyPrinterSettings` 🆕 — change the system-wide pretty-printer settings

</details>

<details>
<summary><b>Service binding publish</b></summary>

- `ValidateServiceBinding` — validate a binding
- `ListServiceBindingTypes` — list available binding types
- `PublishServiceBinding` 🆕 — publish the OData endpoint (V2/V4); the step after `ActivateServiceBinding` that makes the service consumable
- `UnpublishServiceBinding` 🆕 — remove the published endpoint (V2/V4)

</details>

<details>
<summary><b>Transport (CTS)</b></summary>

- `CreateTransport` — create a request; `GetTransport` — query; `ListTransports` — list user transports
- `ReleaseTransport` 🆕 — release (optionally ignore locks/ATC); `DeleteTransport` 🆕 — delete a modifiable request
- `SetTransportOwner` 🆕 — change owner; `AddTransportUser` 🆕 — add a user (own task); `MergeTransport` 🆕 — merge a request into another (SE10 Merge Requests), verified by read-back

</details>

<details>
<summary><b>Data & runtime diagnostics</b></summary>

- `GetTableContents` — table data preview; `GetSqlQuery` — freestyle SQL (ADT Data Preview). A blank cell is returned as an empty string, never as a missing row; branch on `returned_rows`, never on `total_rows` (SAP leaves it 0 unless a count was requested)
- Execute: `RuntimeRunClass` — run a class; `RuntimeRunProgram` — run a program
- Profiler: `RuntimeRunClassWithProfiling` / `RuntimeRunProgramWithProfiling`, `RuntimeCreateProfilerTraceParameters` / `RuntimeListProfilerTraceFiles` / `RuntimeGetProfilerTraceData` / `RuntimeAnalyzeProfilerTrace`
- Diagnostics: `RuntimeGetDumpById` — dump by id; `RuntimeGetGatewayErrorLog` — gateway error log; `RuntimeListSystemMessages` — SM02 messages; `RuntimeListFeeds` — feed list

</details>

<details>
<summary><b>Compact facade (<code>--exposition=compact</code>)</b></summary>

- **27 tools**, routed by an `object_type` parameter, for a minimal tool surface (~2,500 tokens of schema against ~57,000 for `readonly,high`). Used standalone.
- Object lifecycle: `HandlerCreate` / `HandlerGet` / `HandlerUpdate` / `HandlerDelete` / `HandlerActivate` / `HandlerCheckRun` / `HandlerLock` / `HandlerUnlock` / `HandlerValidate`, plus unit tests, profiling and dumps.
- 🆕 Analysis set: `HandlerQuery` (SQL / table contents), `HandlerSearch` (object / source / where-used), `HandlerAtc` (run / worklist / customizing), `HandlerRuntime` (run program / class), `HandlerInactiveObjects` (the inactive-object sweep) and `CallIcfService`. Without these the facade could not reach the analysis, search and runtime families at all.

</details>

The full per-tool list with parameters is in `docs/user-guide/AVAILABLE_TOOLS.md` (and the per-tier `AVAILABLE_TOOLS_READONLY/HIGH/LOW/COMPACT.md`); regenerate with `npm run docs:tools`.

> ℹ️ **ABAP Cloud limitation**: Direct ADT data preview of database tables is blocked by SAP BTP backend policies. The server returns a descriptive error when attempting such operations. On-premise systems continue to support data preview.

## Documentation

### For Users
- **[Docs Index](docs/README.md)** - Full documentation index
- **[Installation Guide](docs/installation/README.md)** - Installation overview and platform guides
- **[User Guide](docs/user-guide/README.md)** - End-user docs (auth, config, tools)
- **[Authentication & Destinations](docs/user-guide/AUTHENTICATION.md)** - Destination-based auth and service keys
- **[Handlers Management](docs/user-guide/HANDLERS_MANAGEMENT.md)** - Enable/disable handler groups
- **Configurator**: `@mcp-abap-adt/configurator` (repo: [`mcp-abap-adt-conf`](https://github.com/fr0ster/mcp-abap-adt-conf)) provides the `mcp-conf` CLI to auto-configure clients
- **Tools by level**
  - [Read-Only Tools](docs/user-guide/AVAILABLE_TOOLS_READONLY.md)
  - [High-Level Tools](docs/user-guide/AVAILABLE_TOOLS_HIGH.md)
  - [Low-Level Tools](docs/user-guide/AVAILABLE_TOOLS_LOW.md)
  - [Legacy System Tools](docs/user-guide/AVAILABLE_TOOLS_LEGACY.md)

### For Administrators
- **[Deployment Docs](docs/deployment/README.md)** - MCP Registry, Docker, release notes
- **[Server Configuration](docs/configuration/YAML_CONFIG.md)** - YAML config reference

### For Developers
- **[Architecture Documentation](docs/architecture/README.md)** - System architecture and design decisions
- **[Development Documentation](docs/development/README.md)** - Testing guides and development resources
- **[CHANGELOG.md](CHANGELOG.md)** - Version history and changes

## Dependencies

This project uses two npm packages:

- **[@mcp-abap-adt/connection](https://www.npmjs.com/package/@mcp-abap-adt/connection)** – connection/auth/session layer
- **[@mcp-abap-adt/adt-clients](https://www.npmjs.com/package/@mcp-abap-adt/adt-clients)** – Builder-first ADT clients

These packages are automatically installed via `npm install` and are published to npm.

---


## Running the Server

> **When do you need this?** Only for standalone deployments (HTTP/SSE mode, where the server runs long-lived for remote clients) or for one-off debugging (run the stdio command manually to see startup logs and verify the env file connects to SAP). If you registered the server in an MCP client via `.mcp.json` (stdio), the client starts and stops the process automatically — do **not** start it manually.

### Running standalone from the command line

> For a **normal MCP‑client install you never run these** — the client spawns the stdio server for you (see [Getting Started](#getting-started)). The commands below are for standalone/remote deployments and debugging only. They assume a global `npm install -g` so `mcp-abap-adt` is on your PATH.

```bash
# Show help
mcp-abap-adt --help

# --- stdio (what MCP clients use; run manually only to debug an env file) ---
# stdio mode with an env destination from the platform sessions store
mcp-abap-adt --transport=stdio --env=dev

# stdio mode with an explicit .env file path
mcp-abap-adt --transport=stdio --env-path=/path/to/my.env

# stdio mode with auth-broker (service keys) via --mcp
mcp-abap-adt --transport=stdio --mcp=TRIAL

# --- HTTP / SSE (standalone or remote deployments only) ---
# HTTP mode (default transport when none is given; works without an .env file)
mcp-abap-adt --transport=http
mcp-abap-adt --transport=http --http-port=8080

# SSE mode
mcp-abap-adt --transport=sse --sse-port=3001
mcp-abap-adt --transport=sse --mcp=TRIAL
```

#### HTTP/SSE server options (standalone/remote only)

These apply only to the `--transport=http` / `--transport=sse` deployments (stdio ignores them):

| Option | CLI | Env | YAML (`--conf`) | Default |
|--------|-----|-----|-----------------|---------|
| Accept `x-sap-*` direct-connection headers | `--no-direct-sap-headers` (to disable) / `--allow-direct-sap-headers=false` | `MCP_ALLOW_DIRECT_SAP_HEADERS=false` | `allow-direct-sap-headers: false` | **on** (back-compat) |
| Max HTTP request body | — | `MCP_HTTP_BODY_LIMIT` (e.g. `10mb`) | env-only | `10mb` |
| Max SSE request body | — | `MCP_SSE_BODY_LIMIT` (falls back to `MCP_HTTP_BODY_LIMIT`) | env-only | `10mb` |
| OAuth browser (auth-broker) | `--browser=<type>` | `MCP_BROWSER` | — | `system` |

Notes:
- Direct `x-sap-*` headers are accepted by default. Disable them when binding a public/untrusted
  interface (`--host=0.0.0.0`) — the server then requires a default destination (`--mcp`/`--env-path`).
  Binding `0.0.0.0` without TLS also logs a cleartext-credential warning.
- The larger body limit is needed because ABAP class/program/DDL source updates easily exceed express's
  100kb default.

### Development Mode
```bash
# Build and run locally
npm run build
npm start

# HTTP mode
npm run start:http

# SSE mode
npm run start:sse

# Legacy v1 server (for backward compatibility)
npm run start:legacy
```

### Environment Configuration

Env resolution:
1. `--env-path=<path|file>` (or `MCP_ENV_PATH`) for explicit `.env` file.
   - Absolute path: used as-is.
   - Relative path or file name only (e.g. `my.env`): resolved from current working directory.
2. `--env=<destination>` for destination file in standard sessions store:
   - Unix: `~/.config/mcp-abap-adt/sessions/<destination>.env`
   - Windows: `%USERPROFILE%\\Documents\\mcp-abap-adt\\sessions\\<destination>.env`
3. Fallback to `.env` in current working directory.

**Example .env file:**
```bash
SAP_URL=https://your-sap-system.com
SAP_CLIENT=100
SAP_AUTH_TYPE=basic
SAP_USERNAME=your-username
SAP_PASSWORD=your-password
```

For JWT authentication (SAP BTP):
```bash
SAP_URL=https://your-btp-system.com
SAP_CLIENT=100
SAP_AUTH_TYPE=jwt
SAP_JWT_TOKEN=your-jwt-token
```

For RFC connection:
```bash
SAP_URL=https://your-legacy-system.com
SAP_CLIENT=100
SAP_AUTH_TYPE=basic
SAP_USERNAME=your-username
SAP_PASSWORD=your-password
SAP_CONNECTION_TYPE=rfc
```

See [RFC Setup Guide](docs/installation/RFC_SETUP.md) for prerequisites (SAP NW RFC SDK).

For client certificate (mTLS) authentication — on-prem HTTP only:
```bash
SAP_URL=https://your-sap-system.com
SAP_AUTH_TYPE=certificate

# PEM format (provide both files):
SAP_CERT_PATH=/path/to/client.crt
SAP_CERT_KEY_PATH=/path/to/client.key

# Or PKCS#12 format (alternative to PEM):
# SAP_CERT_PFX_PATH=/path/to/client.pfx
# SAP_CERT_PASSPHRASE=your-passphrase
```

For Kerberos (SPNEGO) authentication — on-prem HTTP only:
```bash
SAP_URL=https://your-sap-system.com
SAP_AUTH_TYPE=kerberos

# Optional: explicit SPN (default: HTTP@<host>)
# SAP_KERBEROS_SPN=HTTP@mysaphost.corp.example
# Optional: service class used to derive the SPN when SAP_KERBEROS_SPN is unset (default: HTTP)
# SAP_KERBEROS_SERVICE=HTTP
```

**Certificate auth notes:**
- Identifies the client via mTLS — no `SAP_USERNAME` / `SAP_PASSWORD` required.
- Provide either PEM files (`SAP_CERT_PATH` + `SAP_CERT_KEY_PATH`) or a PKCS#12 file (`SAP_CERT_PFX_PATH`), not both.
- On-prem HTTP connections only (`SAP_CONNECTION_TYPE=rfc` is not supported).

**Kerberos auth notes:**
- Requires a valid Kerberos ticket on the host before starting the server. Obtain one with `kinit` or a keytab.
- The optional [`kerberos`](https://www.npmjs.com/package/kerberos) npm package must be installed (needs GSSAPI dev libs on Linux / build tools on Windows): `npm i kerberos`.
- No `SAP_USERNAME` / `SAP_PASSWORD` required — identity comes from the TGT.
- Both auth types bypass the auth-broker; use `.env` directly.
- **NTLM is hard-rejected:** if the SAP system offers NTLM instead of Kerberos/SPNEGO, the connection fails with a clear error rather than silently downgrading. Ensure the system accepts Kerberos (SPNEGO) for your user.

> **⚠️ Help wanted — not yet validated on a live system.** Certificate and Kerberos auth pass full unit coverage but have not been tested against a real SAP system. If you have on-prem **client-certificate** or **Kerberos/SPNEGO** SSO, please try it and [open an issue](https://github.com/fr0ster/mcp-abap-adt/issues) with results — especially whether Kerberos succeeds with a single-leg Negotiate token or your system needs mutual-auth continuation.

**Generate .env from Service Key (JWT):**
```bash
# Install the connection package globally (one-time setup)
npm install -g @mcp-abap-adt/connection

# Generate .env file from service key JSON
mcp-auth auth -k path/to/service-key.json
```

This will automatically create/update `.env` file with JWT tokens and connection details.

**.env comments rule:** only full-line comments are supported (lines that start with `#`).  
Inline comments are not parsed, so keep comments on separate lines.

**Claude recommendation:** place the service key in the service-keys directory and use `--mcp=<destination>` (avoid manual JWT tokens).

### Command-Line Options

**Authentication:**
- `--auth-broker` - Force use of auth-broker (service keys), ignore .env file
- `--auth-broker-path=<path>` - Custom path for auth-broker service keys and sessions
- `--browser-auth-port=<port>` - Override OAuth browser callback port (default: 5000 for HTTP, 4000 for SSE, 4001 for stdio)
- `--connection-type=<http|rfc>` - SAP connection transport: `http` (default) or `rfc`
- `--unsafe` - Enable file-based session storage (persists tokens to disk). By default, sessions are stored in-memory (secure, lost on restart)

When `--mcp=<destination>` is specified, automatic fallback loading of `./.env` is skipped.

**Examples:**
```bash
# Use auth-broker with file-based session storage (persists tokens)
mcp-abap-adt --auth-broker --unsafe

# Use auth-broker with in-memory session storage (default, secure)
mcp-abap-adt --auth-broker

# Custom path for service keys and sessions
mcp-abap-adt --auth-broker --auth-broker-path=~/prj/tmp/ --unsafe
```

See [Client Configuration](docs/user-guide/CLIENT_CONFIGURATION.md) for complete configuration options.

### Handler logging switches
- `AUTH_LOG_LEVEL=error|warn|info|debug` — sets base log level for handler logger; `DEBUG_AUTH_LOG=true` also enables `debug`.
- `HANDLER_LOG_SILENT=true` — fully disables handler logging.
- `DEBUG_CONNECTORS=true` — verbose connection logging in high-level handlers.
- `DEBUG_HANDLERS=true` — enables verbose logs for selected read-only/system handlers.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Source changes have no effect / new tools missing | The server loads `dist/` at startup. Run `npm run build:fast`, then **restart your MCP client**. |
| `CreatePackage` fails with `PAK049` ("enter a valid user") | `SAP_USERNAME` case differs from USR02 (use uppercase, restart), or the user has no validity dates in SU01. |
| Object creation returns HTTP 400 (transport-related) | You passed the **parent** workbench request number — pass the **task** number under it instead. |
| Creation returns 409 but the object does not exist | Not a cache issue (409 is a live SAP response). Check the package allows adding objects (`isAddingObjectsAllowed`) and the user has `S_DEVELOP` ACTVT=01 for that object type. |
| CDS validate returns 400 / `UpdateView` says PUT unsupported | ADT DDL endpoint (SICF `/sap/bc/adt/ddic/ddl`) misconfigured on that system — needs Basis. |
| TLS errors with self-signed certificates | Set `NODE_TLS_REJECT_UNAUTHORIZED=0` in the env (trusted internal networks only). |
| No table data preview on ABAP Cloud | Blocked by BTP backend policy — expected behavior. |

## Development

### Testing
```bash
npm test
```

#### Test logging switches
- `TEST_LOG_LEVEL=error|warn|info|debug` — controls test logger verbosity (DEBUG_TESTS/DEBUG_ADT_TESTS/DEBUG_CONNECTORS force `debug`).
- `TEST_LOG_FILE=/tmp/adt-tests.log` — writes test logs to a file (best-effort).
- `TEST_LOG_SILENT=true` — disables test logging pipeline (console output muted).
- `TEST_LOG_COLOR=true` — adds colored/prefixed tags to test log lines.
- All `console.*` in tests are routed through the test logger with a `[test]` prefix.

### Building
```bash
npm run build
```

### Developer Tools
```bash
# Generate tool documentation
npm run docs:tools

# See tools/README.md for more developer utilities
```

## Changelog & Enhancements

This fork builds on upstream fr0ster v7.0.3, maintained independently. It adds a set of tools and fixes a number of issues surfaced on a live S/4HANA system (SAP_BASIS 7.56, "DM2"). All of the below are live-verified.

### Added / absorbed tools

- **ATC checks**: `RunAtc` (one-shot, multi-object, with `quickfix_info`/`link`/`location`), `GetAtcWorklist`, `GetAtcCustomizing`. ATC **exemption-request** tools (`atcRequestExemption` etc.) are deliberately **not** implemented — suppressing findings should remain a human decision.
- **Quick fixes**: `GetFixProposals`, `GetFixEdits` (compute edit deltas only; never write source).
- **Service binding publish**: `PublishServiceBinding` / `UnpublishServiceBinding` (OData V2/V4) — the "actually consumable" step after `ActivateServiceBinding`.
- **Repository generators**: `GenerateRepoObjects` — drives the ADT repository generators (`uiservice` / `webapiservice` / `smbc`) to scaffold a whole RAP OData service, or a Fiori maintenance object, from one DB table. No `@mcp-abap-adt/adt-clients` wrapper exists, so it talks straight to `/sap/bc/adt/**/generators/<type>` (same direct-REST pattern as the transport lifecycle tools). For `uiservice` / `webapiservice` the generated service binding is fetched back in the same call; the SRVB GET advertises **both** v1 and v2 SRVB media types in `Accept` (SAP returns 406 if either is missing). Covered by unit tests; the live smoke test is **disabled by default** (enable `generate_repo_objects` in `tests/test-config.yaml` once a source table is ready) — see the validation note below.
- **Source formatting**: `PrettyPrintSource`, `GetPrettyPrinterSettings`, `SetPrettyPrinterSettings`.
- **Revisions / docs**: `GetObjectRevisions`, `GetAbapDocumentation`.
- **Transport lifecycle**: `ReleaseTransport`, `DeleteTransport`, `SetTransportOwner`, `AddTransportUser` (complementing the existing `CreateTransport` / `ListTransports`).
- **Message class / lock object / transformation CRUD** 🆕 — three object types that had no create tool (nor an `@mcp-abap-adt/adt-clients` wrapper). The live `/sap/bc/adt/discovery` exposes create collections for all three, so they are driven via direct `makeAdtRequest`:
  - **Transformation (XSLT)**: `CreateXslt`, `GetXslt`, `UpdateXslt`, `DeleteXslt`, `ActivateXslt`
  - **Message class (MSAG)**: `CreateMessageClass`, `GetMessageClass`, `UpdateMessageClass` (UPSERT — omitted messages are kept, not deleted), `DeleteMessageClass`, `AddMessage`, `UpdateMessage`
  - **Lock object (ENQU)**: `CreateLockObject`, `GetLockObject`, `UpdateLockObject`, `DeleteLockObject`, `ActivateLockObject` (activation auto-generates the ENQUEUE_/DEQUEUE_ function modules)
- **Build identity** 🆕 — `GetSession` reports `server_version`, `build_timestamp`, `started_at` and `pid`, and every error message ends with `[mcp-abap-adt <version>, built <ts>, pid <n>]`. The timestamp is frozen when the process loads, not read per call: rebuilding while a server runs would otherwise make the tool claim a build it is not running. Quote it when reporting a problem.
- **Object name-length guard** 🆕 — `Create*` fail fast when a name exceeds the DDIC/OO limit (table/view 16, most types 30, function_group 26, program 40, message_class 20), because SAP silently truncates over-long names and then reports a misleading "already exists".

Implementation aligned with [marcellourbani/abap-adt-api](https://github.com/marcellourbani/abap-adt-api). Debugger, abapGit, and rename/extract-method refactoring were deliberately not absorbed.

### Key fixes

- **P1 — logon-language mismatch.** The connection layer never sent `sap-language`, so the logon language defaulted to the account default (e.g. ZH) while payloads declared EN — breaking every description-bearing create (CreateView 400, CreateDataElement "missing description", …). Fix: inject `sap-language == SAP_LANGUAGE` on every request so logon and declared languages agree by construction. Verified across 12 object types.
- **P2 — GetWhereUsed 404 for all types.** The low-level `getWhereUsedList` does a `/usageReferences/scope` pre-flight that S/4 7.56 doesn't expose. Fix: a single direct POST (empty `<affectedObjects/>`, default scope) like Eclipse.
- **P3 — misleading `total_rows: 0`.** SAP returns 0 unless a count is requested (not a bug). GetSqlQuery / GetTableContents now also return `returned_rows` (actual row count).
- **P4 — scrambled descriptions in GetPackageContents/Tree.** Under a lingering stateful session `/repository/nodestructure` bleeds a node's DESCRIPTION from a previously-fetched node. Fix: send an explicit `x-sap-adt-sessiontype: stateless` header for the node fetch to terminate the lingering session (`setSessionType('stateless')` only omits the header — insufficient).
- **P6 — CreatePackage true top-level package.** adt-clients `AdtPackage` hard-throws "Super package is required" before any network call. Fix: when no super package (and not a structure package), take a direct-POST bypass (low-level validation + create with empty `<pak:superPackage/>`, injecting `responsible`/`masterSystem`), inheriting the P1 language injection.
- **Domain create/update**: the low-level regex patch could only replace existing elements, so a bare-created domain silently dropped datatype/length/decimals (decimals=0 treated as falsy). Fix: `writeDomainContent` reads → parses → inserts the `<doma:content>` subtree → writes back.
- **Structure create**: `CreateStructure` used to ignore `fields` and produce an empty structure. Fix: generate DDL from fields/includes and write it.
- **CDS create**: `CreateView` now POSTs `/ddic/ddl/sources` directly with `sap-language` to satisfy the language-equality check (`DDIC_ADT_DDLS/016`).
- **Existence pre-check (Plan A)**: 8 `Create*` handlers now interpret the validate result before creating and fail fast on a name clash — language-independently (via the exception `type` id, not localized text) — avoiding half-created objects.

> ⚠️ Not yet validated on a live system: certificate / Kerberos auth, `SetPrettyPrinterSettings`, and `GenerateRepoObjects` (unit-tested only — its integration smoke test ships **disabled**; enable the `generate_repo_objects` cases in `tests/test-config.yaml` and point them at a real source table to exercise it).

## Contributors

Thank you to all contributors! See [CONTRIBUTORS.md](CONTRIBUTORS.md) for the complete list.

---

**Acknowledgment**: This project was originally inspired by [mario-andreschak/mcp-abap-adt](https://github.com/mario-andreschak/mcp-abap-adt). We started with the core concept and then evolved it into an independent project with our own architecture and features.
