# RFC Connection Setup

RFC is an alternative connection transport to HTTP. It works with any SAP system supported by the SAP NW RFC SDK. The RFC session is inherently stateful, so lock handles persist across calls without requiring HTTP stateful sessions.

## Prerequisites

### 1. SAP NW RFC SDK

Download from [SAP Support Portal](https://support.sap.com/en/product/connectors/nwrfcsdk.html) (requires S-user).

Extract to a local directory, e.g. `C:\nwrfcsdk\nwrfcsdk` (Windows) or `~/nwrfcsdk` (Linux/macOS).

### 2. Environment Variables

The SDK requires two shell-level environment variables. These **must** be set in the shell before starting Node.js — `.env` files do not work for this.

**Windows (PowerShell profile — persistent):**

Add to `$PROFILE` (usually `~\Documents\PowerShell\Microsoft.PowerShell_profile.ps1`):

```powershell
$env:SAPNWRFC_HOME = "C:\nwrfcsdk\nwrfcsdk"
$env:PATH = "C:\nwrfcsdk\nwrfcsdk\lib;$env:PATH"
```

**Windows (System Environment Variables — persistent):**

1. Open **System Properties** > **Environment Variables**
2. Add `SAPNWRFC_HOME` = `C:\nwrfcsdk\nwrfcsdk`
3. Append `C:\nwrfcsdk\nwrfcsdk\lib` to `PATH`

**Linux/macOS (bash/zsh profile — persistent):**

Add to `~/.bashrc` or `~/.zshrc` (on Linux, see the note below first):

```bash
export SAPNWRFC_HOME=~/nwrfcsdk
export PATH=$SAPNWRFC_HOME/lib:$PATH
# Linux only:
export LD_LIBRARY_PATH=$SAPNWRFC_HOME/lib:${LD_LIBRARY_PATH:-}
```

> **Linux, measured:** when `@mcp-abap-adt/sap-rfc-lite` is built with
> `SAPNWRFC_HOME` set, the native module records the SDK's `lib` directory as
> its RUNPATH and connects with **no** `LD_LIBRARY_PATH`. That path is
> absolute, so moving the SDK afterwards breaks the module — rebuild it.

### 3. @mcp-abap-adt/sap-rfc-lite Package

```bash
SAPNWRFC_HOME=/path/to/nwrfcsdk npm install @mcp-abap-adt/sap-rfc-lite --no-save
```

`@mcp-abap-adt/sap-rfc-lite` is a lightweight fork of the archived `node-rfc` package, containing only the API surface needed for ADT RFC connections. It is loaded dynamically at runtime — it is not a declared dependency.

Verify installation:

```bash
node -e "try { require('@mcp-abap-adt/sap-rfc-lite'); console.log('OK'); } catch(e) { console.log(e.message); }"
```

### 4. SAP Authorization

The SAP user needs `S_RFC` authorization for function module `SADT_REST_RFC_ENDPOINT`. See SAP Note 3569684.

## .env Configuration

For RFC connections, use two separate variables — one for authentication, one for connection type:

```env
SAP_URL=http://saphost:8000
SAP_USERNAME=DEVELOPER
SAP_PASSWORD=secret
SAP_CLIENT=100
SAP_AUTH_TYPE=basic
SAP_CONNECTION_TYPE=rfc
```

- `SAP_AUTH_TYPE` — authentication method (`basic` or `jwt`). RFC uses basic auth with username/password.
- `SAP_CONNECTION_TYPE` — transport layer (`http` or `rfc`).

## Through a SAProuter

For a system reachable only through a SAProuter (SAP GUI connects with a route
string such as `/H/1.2.3.4/H/`), add the route to the `.env`:

```env
SAP_URL=http://<application-server>:8000
SAP_CONNECTION_TYPE=rfc
SAP_SAPROUTER=/H/1.2.3.4/H/
```

`<application-server>` is the host from SAP Logon's *Application Server* field,
as seen from the router, not from your machine. Set `SAP_SYSNR` when the HTTP
port is not `80XX`.

RFC payload compression is off by default: with the NW RFC SDK's compression
on, a request body that compresses badly (base64 — e.g. the pre-activation
check of a large program) dumps on the server with `XML_FORMAT_ERROR` while the
RFC parameters are read. Set `SAP_RFC_COMPRESSION=on` to keep the SDK default.

**Why RFC and not HTTP.** A router whose `saprouttab` carries only `S` entries
permits SAP protocols (SAP GUI, RFC) and refuses raw TCP routes with
`route permission denied`. HTTP cannot cross such a router: sent inside a SAP
protocol route it does reach the ICM, but the router then rejects the ICM's
plain HTTP reply (`Network packet too big`). Only a `P` entry for the HTTP port
would change that, and that is the router owner's decision.

The SDK writes `rfc*.trc` trace files even at trace level 0. This server sends
them to `<tmpdir>/mcp-abap-adt-rfc-trace` instead of the working directory;
set `RFC_TRACE_DIR` to choose another place.

`SAP_LANGUAGE`, when it reaches the process, is also passed as the RFC logon
language (the dependency alone always logs on in EN).

## Several clients of the same system

One server can reach several clients of ONE system:

```
SAP_CLIENT=100
SAP_CLIENTS=100,800
# optional, only when client 800 uses another user:
# SAP_CLIENT_800_USERNAME=...
# SAP_CLIENT_800_PASSWORD=...
```

Every tool then takes an optional `sap_client` (`"100"` or `"800"`); omitted
means `SAP_CLIENT`. Each client gets its own connection, opened on first use, and
every result ends with a `sap_client: <n>` line naming the client that answered.
`GetSession` lists the configured clients and which are connected.

Repository objects (classes, CDS, programs) are shared by all clients of a
system: changing a class with `sap_client: "800"` changes the same class. If
client 800 forbids repository changes (SCC4), SAP's refusal is returned as is.
Basic authentication only. Works over HTTP and RFC alike, including through a
SAProuter.

## How It Works

1. `SAP_CONNECTION_TYPE=rfc` tells the server to create an `RfcAbapConnection` instead of HTTP
2. The connection calls SAP function module `SADT_REST_RFC_ENDPOINT` for every ADT request
3. The RFC session is inherently stateful — lock handles persist across calls
4. Host and system number are derived from `SAP_URL` (port 80XX -> system number XX)

## Troubleshooting

### "@mcp-abap-adt/sap-rfc-lite is not available"

SAP NW RFC SDK is not installed or not in PATH. Check:

```bash
echo $SAPNWRFC_HOME
node -e "require('@mcp-abap-adt/sap-rfc-lite')"
```

### "The specified module could not be found: sapnwrfc.node"

The native module exists but can't load SDK DLLs. Ensure `SAPNWRFC_HOME/lib` is in PATH **before** starting Node.js. Restart your terminal after setting variables.

### "RFC connection is not open" / "Failed to open RFC connection"

The connection opens itself on first use; a failure there names SAP's reason.
Check SAP system availability, credentials, and `S_RFC` authorization. Behind a
SAProuter, `route permission denied` means the router's `saprouttab` does not
permit your machine or that host/port — not a credentials problem.
