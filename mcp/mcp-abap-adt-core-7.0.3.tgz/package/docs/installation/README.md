# Installation Documentation

This directory contains installation guides for the MCP ABAP ADT Server.

## Files

- **[INSTALL_ZH.md](INSTALL_ZH.md)** — 中文安装文档（权威）。三条来源（Hi 平台 / 飞书技能仓库 / git clone）× 三种注册方式，含 env 字段、验证步骤、更新与排错。
- **[INSTALLATION.md](INSTALLATION.md)** - Main installation guide with platform-specific quick links
- **[CLINE_CONFIGURATION.md](CLINE_CONFIGURATION.md)** - Cline client configuration examples
- **[platforms/](platforms/)** - Platform-specific installation guides
  - `INSTALL_WINDOWS.md` - Windows installation using PowerShell and winget
  - `INSTALL_MACOS.md` - macOS installation using Homebrew
  - `INSTALL_LINUX.md` - Linux installation using package managers
- **[examples/README.md](examples/README.md)** - Example client configurations
  - `SERVICE_KEY_SETUP.md` - Service key setup for destination-based auth

## Quick Start

See the main [INSTALLATION.md](INSTALLATION.md) file for a complete overview and quick start instructions for your platform.
