# 从零安装 mcp-abap-adt

一台干净机器 → 能在 Claude Code / Codex 里调用 SAP ABAP 工具。全程约 10 分钟。

本文覆盖**飞书技能仓库安装**（本仓库的分发方式，含 npm 版没有的增强工具）。每条命令都在
Windows / macOS / Linux 上按同一套流程执行，差异处会分开写。

---

## 0. 先决条件

| 项 | 要求 | 检查 |
|---|---|---|
| Node.js | ≥ 22 | `node -v` |
| npm | ≥ 9 | `npm -v` |
| 飞书 CLI | 已安装且**已登录** | `lark-cli auth status` → user 为 `ready` |
| SAP 系统 | SICF 节点 `/sap/bc/adt` 已激活 | 浏览器打开 `<SAP_URL>/sap/bc/adt/discovery` 应要求登录并返回 XML |
| SAP 账号 | 具备 ADT 权限；写操作还需 `S_DEVELOP` 对应活动 | 见下方「权限不足的表现」 |

装 / 登录飞书 CLI：

```bash
npm i -g @larksuite/cli
lark-cli auth login
```

---

## 1. 取代码：两条路，选一条

| | 来源 | 是否需要编译 | 适合 |
|---|---|---|---|
| **A. 飞书技能仓库** | `install-skills.mjs` | **不需要**（含预构建 `dist/`）| 只想用 |
| **B. git clone** | 本仓库 | **需要**（`dist/` 不进 git）| 要改代码 / 内网无飞书 CLI |

### A. 飞书技能仓库（默认）

`install-skills.mjs` **不做全局安装**——每次现下载（它会自更新），并且**在你下载它的那个目录下运行**。

```bash
node install-skills.mjs --skill mcp-abap-adt
```

安装器会问装到哪里，并**打印最终安装路径**：

- **全局** → `~/.mcp/mcp-abap-adt`
- **本地** → 当前目录下的 `mcp-abap-adt/`

> 记住这个路径。**后面每一步都在这个副本目录里执行**，本文记作 `<副本>`。

包内含预构建的 `dist/`，**不需要编译**。之后走第 2 节。

### B. 从源码安装（git clone）

`dist/` 在 `.gitignore` 里、**不进版本库**，所以克隆下来必须自己编译，而编译要用到
devDependencies（tsc、biome），**不能加 `--omit=dev`**：

```bash
git clone <仓库地址> mcp-abap-adt
cd mcp-abap-adt
npm install            # 完整安装，含 devDependencies
npm run build          # biome 检查 + tsc 编译 + 清理 dist 孤儿
node bin/mcp-abap-adt.js --version    # 应打印版本号
```

编译完可以把开发依赖删掉以省空间（`dist/` 已经生成，之后不再需要它们）：

```bash
npm prune --omit=dev
```

> 走这条路的话**跳过第 2 节**（依赖已经装好了），直接到第 3 节注册。

---

## 2. 装运行时依赖（仅 A 路需要）

安装包**不含 `node_modules`**（16 个生产依赖）。不装这一步 server 起不来。

```bash
cd <副本>
npm install --omit=dev --ignore-scripts
```

`--ignore-scripts` 跳过 husky 之类属于 devDependencies 的生命周期钩子——在 `--omit=dev` 下它们必然
失败。第 1 步给 `install-skills.mjs` 加 `--install-deps` 可以让它自动做这件事。

验证：

```bash
node bin/mcp-abap-adt.js --version     # 应打印版本号，如 7.0.3
```

---

## 3. 注册到 MCP 客户端

三种方式，任选一种。

### 方式 0：`claude mcp add`（最直接，推荐给 Claude Code）

不依赖本仓库的任何脚本，用 Claude Code 自己的 CLI 一条命令注册。**路径必须写绝对路径。**

```bash
claude mcp add adt-dm2 -s user \
  -e NODE_TLS_REJECT_UNAUTHORIZED=0 \
  -- node /abs/path/to/mcp-abap-adt/bin/mcp-abap-adt.js \
     --env-path=/abs/path/to/env/dm2310.env \
     --exposition=readonly,high
```

Windows PowerShell 用反引号 `` ` `` 换行，或干脆写成一行。

- `adt-dm2` —— server 名，随便起，客户端里按它区分
- `-s user` —— 用户级（所有工程可用）；换成 `-s project` 则写进当前工程的 `.mcp.json`
- `-e NODE_TLS_REJECT_UNAUTHORIZED=0` —— 自签证书时需要
- `--` 之后是启动命令，`--env-path` 指向你自己准备的 env 文件（**绝对路径**，见第 4 节字段说明）

这种方式下 env 文件放哪儿都行——你自己建、自己指。想连多套系统就多跑几次，换 server 名和
`--env-path`。

Codex 用户自行在 `~/.codex/config.toml` 写等价的 `[mcp_servers.adt-dm2]` 块。

### 方式 A：`install-mcp.js` 全局注册

由脚本代劳：复制 env 模板到标准 sessions 目录，并同时给 Claude Code 与 Codex 写配置。
**在 `<副本>` 目录下执行。**

env 放标准 sessions 目录，server 条目写进用户级配置，**所有工程共用**。

```bash
node scripts/install-mcp.js --global --name=dev
```

- `--name=dev` 决定 env 文件名与 server 标识 `adt-dev`（默认 `mysystem`）
- `--exposition=readonly,high` 是默认值，见第 6 节

脚本会：把 `.env.example` 复制到 sessions 目录下的 `dev.env`；把 stdio 条目写进 `~/.claude.json`
（写前自动备份）；**检测到 `~/.codex/` 时**同时写等价的 `[mcp_servers.adt-dev]` 到
`~/.codex/config.toml`。用 `--codex` 强制、`--no-codex` 跳过。

生成的条目形如：

```json
"adt-dev": {
  "command": "node",
  "args": ["<副本绝对路径>/bin/mcp-abap-adt.js", "--env=dev", "--exposition=readonly,high"],
  "env": { "NODE_TLS_REJECT_UNAUTHORIZED": "0" }
}
```

### 方式 B：按工程注册

env 与 `.mcp.json` 都落在某个工程里，配置随工程走。

```bash
node scripts/install-mcp.js --target=/path/to/my-abap-project --name=dev
```

生成 `<工程>/env/dev.env` 与 `<工程>/.mcp.json`（已存在则合并，不覆盖 env）。

> **把 `env/` 加进该工程的 `.gitignore`——env 文件里有明文密码。**

---

## 4. 填连接信息

编辑上一步生成的 env 文件。

**方式 A 的路径：**

- macOS / Linux：`~/.config/mcp-abap-adt/sessions/dev.env`
- Windows：`%USERPROFILE%\Documents\mcp-abap-adt\sessions\dev.env`

**方式 B 的路径：** `<工程>/env/dev.env`

```bash
SAP_URL=http://your-sap-host:8000
SAP_CLIENT=100
SAP_LANGUAGE=en
SAP_SYSTEM_TYPE=onprem          # onprem | cloud | legacy
SAP_CONNECTION_TYPE=http        # http | rfc
SAP_AUTH_TYPE=basic             # basic | jwt
SAP_USERNAME=YOUR_USER
SAP_PASSWORD=your-password
NODE_TLS_REJECT_UNAUTHORIZED=0  # 自签证书时需要
```

**这个文件含明文密码，永远不要提交。** 其他认证方式（JWT / BTP 服务密钥）见 README 的
「env 文件详细配置」。

### `SAP_LANGUAGE` 有副作用，值得知道

SAP 把**登录语言**当作新建对象的原始语言。本 server 会把 `SAP_LANGUAGE`（默认 `EN`）注入每一个
请求，所以通过它创建的对象原始语言恒为该值，而同一个人在 SE11/SE80 手工建的对象跟随**他自己的**
登录语言。想让两者一致，就把 `SAP_LANGUAGE` 设成团队实际使用的语言。

---

## 5. 重启客户端并验证

配置**只在客户端启动时读取**。重启 Claude Code（和 / 或 Codex）。不需要手工启动 server——客户端会
以 stdio 拉起它。

验证顺序，从最不可能出错的开始：

```
1. GetSession        → 返回 server_version / build_timestamp / pid
                       这一步只证明 server 起来了，还没碰 SAP
2. SearchObject      → object_name: "T100"
                       返回一行 T100 / TABL/DT / Messages / SDIC 即连接与授权正常
3. GetTableContents  → table_name: "T000", max_rows: 5
                       能读到数据即 Data Preview 通路正常
```

`GetSession` 返回的 `build_timestamp` 是**加载进内存的那个构建**（进程启动时冻结），不是磁盘上
当前的文件。记录问题时带上它，就不会出现「你测的到底是哪个版本」这种争论。

---

## 6. 选择暴露哪些工具

`--exposition` 决定客户端能看到多少工具。工具定义本身要占上下文，**装完就固定支出**，与是否调用无关。

| 档位 | 工具数 | 适合 |
|---|---|---|
| `readonly` | 70 | 只读分析、代码审查 |
| `readonly,high`（默认） | ~228（70 + 163，只读工具会与 high 去重） | 日常开发，读 + 写 + 激活 |
| `readonly,low` | 70 + 127 | 需要手工控制 lock / unlock / session 的场景 |
| `compact` | 27 | 上下文吃紧时；按对象类型路由的门面，覆盖 CRUD + 检查 + 分析 + 运行时 |

各档位的完整清单在 `docs/user-guide/AVAILABLE_TOOLS_<档位>.md`。

约束：`high` 与 `low` 互斥；`compact` **必须单独使用**，不能与其他档位组合。

改档位就是改客户端配置里那一行 `--exposition=`，然后重启客户端。

---

## 7. 连多个 SAP 系统

一个 server 进程 = 一个 SAP 系统。要连多套，就注册多个条目，每个一份 env：

```bash
node scripts/install-mcp.js --global --name=dev
node scripts/install-mcp.js --global --name=qas
node scripts/install-mcp.js --global --name=prd
```

得到 `adt-dev` / `adt-qas` / `adt-prd` 三个 server，各自的 env 文件在同一个 sessions 目录下。

**注意上下文成本是叠加的**：三个系统 × `readonly,high` ≈ 684 个工具定义常驻。生产系统建议只给
`readonly`，或整体改用 `compact`。

---

## 8. 出问题时

**server 根本没出现（客户端里看不到 ABAP 工具）**

1. 配置只在启动时读——确认真的重启了客户端，不是重开一个窗口
2. 在副本目录手工跑一次：`node bin/mcp-abap-adt.js --version`
   - 报 `Cannot find module '../dist/server/launcher.js'` → **`dist/` 不存在**。你是 git clone 装的，
     需要 `npm install && npm run build`（见 1-B）；`dist/` 不进版本库
   - 报 `Cannot find module '@mcp-abap-adt/...'` → 生产依赖没装（见第 2 节）
   - 编译报缺 `tsc` / `biome` → 装依赖时加了 `--omit=dev`，编译需要 devDependencies，重跑 `npm install`
3. 检查客户端配置里的路径是否是**绝对路径**（`claude mcp add` 与 `.mcp.json` 都不接受 `~`）
4. `claude mcp list` 看条目在不在、命令对不对

**连接失败**

- `ENOTFOUND` → `SAP_URL` 主机名解析不了；先 `nslookup`，注意是否需要 VPN
- 自签证书报 TLS 错 → env 里 `NODE_TLS_REJECT_UNAUTHORIZED=0`
- 404 且路径含 `/sap/bc/adt` → SICF 节点没激活，找 Basis

**权限不足的表现**

读操作能跑、写操作报 403 或 SAP 自己的授权消息 → 缺 `S_DEVELOP` 对应活动。本 server 会把 SAP 的
原话透传出来，照着那句话找 Basis 即可。

**报错信息末尾的方括号**

每条错误都带 `[mcp-abap-adt <版本>, built <时间>, pid <进程号>]`。反馈问题时连它一起贴——它说明是
哪个构建、哪个进程回答的。

---

## 9. 更新

重跑第 1 步即可（安装器会自更新），然后**重新装一次依赖**，因为依赖清单可能变了：

```bash
node install-skills.mjs --skill mcp-abap-adt
cd <副本> && npm install --omit=dev --ignore-scripts
```

注册信息（客户端配置、env 文件）不受影响，不需要重做第 3、4 步。**更新后要重启客户端**，否则跑的
还是旧进程——用 `GetSession` 的 `build_timestamp` 确认。

---

## 相关文档

- [README（中文）](../../README.zh-CN.md) — 完整功能与 env 字段说明
- [工具清单](../user-guide/AVAILABLE_TOOLS.md) — 全部工具及参数
- [认证与 destination](../user-guide/AUTHENTICATION.md) — JWT / BTP 服务密钥
- [RFC 安装](RFC_SETUP.md) — BASIS < 7.50 的 legacy 系统
