# 安装 mcp-abap-adt（中文）

一台干净机器 → 能在 Claude Code / Codex 里调用 SAP ABAP 工具。

**本文是安装方式的权威文档。** 两份 README 只给决策表和最短命令，细节、验证和排错都在这里。

---

## 目录

1. [先决条件](#1-先决条件)
2. [选哪条路](#2-选哪条路)
3. [路线 H：Hi 平台（`hi` CLI）](#3-路线-hhi-平台hi-cli)
4. [路线 A：飞书技能仓库](#4-路线-a飞书技能仓库)
5. [路线 B：从源码（git clone）](#5-路线-b从源码git-clone)
6. [注册到 MCP 客户端（A / B 路）](#6-注册到-mcp-客户端a--b-路)
7. [填连接信息](#7-填连接信息)
8. [重启并验证](#8-重启并验证)
9. [选择暴露哪些工具](#9-选择暴露哪些工具)
10. [连多个 SAP 系统](#10-连多个-sap-系统)
11. [更新](#11-更新)
12. [出问题时](#12-出问题时)

---

## 1. 先决条件

| 项 | 要求 | 检查 |
|---|---|---|
| Node.js | ≥ 22（本地验证用 v24） | `node -v` |
| npm | ≥ 9 | `npm -v` |
| CLI | 按下一节选的路，**只需其中一个** | H 路 `hi whoami --json`；A 路 `lark-cli auth status`（user 为 `ready`）；B 路不需要 |
| SAP 系统 | SICF 节点 `/sap/bc/adt` 已激活 | 浏览器打开 `<SAP_URL>/sap/bc/adt/discovery`，应要求登录并返回 XML |
| SAP 账号 | 具备 ADT 权限；写操作还需 `S_DEVELOP` 对应活动 | 见[出问题时](#12-出问题时) |

装 / 登录对应的 CLI：

```bash
# H 路：Hi 平台
hi login

# A 路：飞书
npm i -g @larksuite/cli
lark-cli auth login
```

---

## 2. 选哪条路

三条路的区别只有两件事：**依赖是否随包到位，注册是否自动完成。**

| | 来源 | 编译 | 运行时依赖 | 客户端注册 | 适合 |
|---|---|---|---|---|---|
| **H. Hi 平台** | `hi project init` | 不需要 | **已包含** | **自动**（Claude + Codex） | 公司在 Hi 上发布了它 |
| **A. 飞书技能仓库** | `install-skills.mjs` | 不需要 | 自己装 | 自己做 | 只想用，公司走飞书分发 |
| **B. git clone** | 本仓库 | **需要** | 自己装 | 自己做 | 要改代码 / 内网没有上面两个 CLI / 需要 Kerberos |

两个容易踩的反差，写在前面：

- **A 路装依赖要加 `--omit=dev`，B 路绝对不能加。** A 路拿到的是预构建包，只缺运行时依赖；B 路必须自己编译，而编译要用 `tsc` 和 `biome`，它们是 devDependencies。
- **H 路和 A 路都用不了 Kerberos 认证。** 两者的依赖都以 `--ignore-scripts` 安装，`kerberos` 的原生二进制不会下载（好处是包跨平台）。要 Kerberos 走 B 路。

选好后：**H 路读第 3 节，然后直接跳到第 7 节**（第 6 节的注册它已经替你做了）；A 路读第 4 节；B 路读第 5 节。

---

## 3. 路线 H：Hi 平台（`hi` CLI）

步骤最少的一条：一条命令完成解压、装依赖（包内自带）和客户端注册。

### 3.1 登录并选择项目

```bash
hi whoami --json                 # 确认登录身份、公司、设备
hi project list --json           # 可用项目
hi project use <项目代码>         # 把当前目录关联到资产所授权的项目
```

### 3.2 安装

`--root` **一律传绝对路径**，不要依赖当前工作目录：

```bash
hi project init --root <绝对路径>/你的工程 --json
```

### 3.3 它到底做了什么

落地结构：

```
<root>/.hi/mcp/mcp-abap-adt/
├── .env                          ← 凭据，权限 0600
└── <asset_version_id>/           ← 一个版本一个目录，新旧并存
    ├── bin/  dist/  node_modules/
    └── hi-mcp-server.json
```

- **安装是原子的**：先解压到同级临时目录，校验入口文件确实存在，再整体改名落位；失败就删掉临时目录。不会留下装了一半的版本。
- **写 `.mcp.json` 只动自己那一个键**：读出现有内容，只替换 `mcpServers["mcp-abap-adt"]`，其余 server 条目和顶层字段原样保留；文件不是合法 JSON 时会停手报错，不覆盖。
- 同时写 `~/.codex/config.toml` 的等价条目，所以 Claude Code 和 Codex 一次到位。

生成的启动条目形如：

```jsonc
"mcp-abap-adt": {
  "command": "<node 的绝对路径>",
  "args": [
    "--env-file=<root>/.hi/mcp/mcp-abap-adt/.env",
    "<root>/.hi/mcp/mcp-abap-adt/<版本>/bin/mcp-abap-adt.js",
    "--transport=stdio",
    "--env-path=<root>/.hi/mcp/mcp-abap-adt/.env"
  ]
}
```

> `--env-file` 是 Node 原生参数，只把变量注入 `process.env`；`--env-path` 是本 server 自己的参数，它需要知道**文件路径本身**（auth-broker 要用）。两者都指向同一个文件。

### 3.4 必须加进 `.gitignore`

```gitignore
.hi/
.hi-pack/
.mcp.json
```

三者都是本机状态。`.mcp.json` 尤其不能提交——它的 `args` 里有三处绝对路径，**其中一处是已安装的版本目录名**，别人一发新版它就指向不存在的目录。

### 3.5 填凭据

首次安装时 `hi` 用包内 `.env.example` 生成 `<root>/.hi/mcp/mcp-abap-adt/.env`：**注释和公开默认值原样保留，键名以 `USERNAME` 或 `PASSWORD` 结尾的一律置空。** 什么都不会替你填，也不上传。

```bash
hi mcp doctor --json    # 列出仍为空的必填变量，并检查台账 / .mcp.json / 本地仓一致性
hi mcp list --json      # 已装的 server 与版本
```

字段说明见[第 7 节](#7-填连接信息)，填完跳到[第 8 节](#8-重启并验证)。

---

## 4. 路线 A：飞书技能仓库

### 4.1 取包

`install-skills.mjs` **不做全局安装**——每次现下载（它会自更新），并且**在你下载它的那个目录下运行**：

```bash
node install-skills.mjs --skill mcp-abap-adt
```

安装器会问装到哪里，并**打印最终安装路径**：

- **全局** → `~/.mcp/mcp-abap-adt`
- **本地** → 当前目录下的 `mcp-abap-adt/`

> 记住这个路径。后面每一步都在这个副本目录里执行，本文记作 `<副本>`。

包内含预构建的 `dist/`，**不需要编译**。

### 4.2 装运行时依赖（不能跳）

飞书的发布器在机制上不携带 `node_modules`（它把这个目录名写死在忽略列表里），所以拿到的包里没有依赖，**不装 server 起不来**：

```bash
cd <副本>
npm install --omit=dev --ignore-scripts
node bin/mcp-abap-adt.js --version     # 应打印版本号，如 7.0.3
```

`--ignore-scripts` 跳过 husky 之类属于 devDependencies 的生命周期钩子——在 `--omit=dev` 下它们必然失败。第 4.1 步给 `install-skills.mjs` 加 `--install-deps` 可以让它自动做这件事。

> 副作用：`kerberos` 的原生二进制也不会下载，所以这样装完用不了 Kerberos 认证。需要就去掉 `--ignore-scripts` 重装一次，前提是本机有编译工具链。

接着做[第 6 节](#6-注册到-mcp-客户端a--b-路)。

---

## 5. 路线 B：从源码（git clone）

`dist/` 在 `.gitignore` 里、**不进版本库**，所以克隆下来必须自己编译，而编译要用到 devDependencies（`tsc`、`biome`）——**这里不能加 `--omit=dev`**，与 A 路的要求正好相反：

```bash
git clone <仓库地址> mcp-abap-adt
cd mcp-abap-adt
npm install            # 完整安装，含 devDependencies
npm run build          # biome 检查 + tsc 编译 + 清理 dist 孤儿产物
node bin/mcp-abap-adt.js --version    # 应打印版本号
```

编译完可以删掉开发依赖省空间（`dist/` 已生成，之后用不到它们）：

```bash
npm prune --omit=dev
```

接着做[第 6 节](#6-注册到-mcp-客户端a--b-路)。

---

## 6. 注册到 MCP 客户端（A / B 路）

**H 路跳过本节。** 下面三种方式任选一种。

### 方式 0：`claude mcp add`（推荐，最直接）

不依赖本仓库的任何脚本，用 Claude Code 自己的 CLI 一条命令注册。**路径必须写绝对路径**（`~` 不会被展开）。

```bash
claude mcp add adt-dm2 -s user \
  -e NODE_TLS_REJECT_UNAUTHORIZED=0 \
  -- node /abs/path/to/mcp-abap-adt/bin/mcp-abap-adt.js \
     --env-path=/abs/path/to/env/dm2310.env \
     --exposition=readonly,high
```

Windows PowerShell 用反引号 `` ` `` 换行，或干脆写成一行。

- `adt-dm2` —— server 名，随便起，客户端里按它区分
- `-s user` —— 用户级（所有工程可用）；换成 `-s project` 则写进当前工程的 `.mcp.json`
- `-e NODE_TLS_REJECT_UNAUTHORIZED=0` —— 自签证书时需要
- `--` 之后是启动命令，`--env-path` 指向你自己准备的 env 文件（绝对路径）

env 文件放哪儿都行——你自己建、自己指。可以直接从 `<副本>/.env.example` 复制一份改。

**Codex 用户注意**：这条路只写 Claude Code 的配置，Codex 要自己在 `~/.codex/config.toml` 写等价的 `[mcp_servers.adt-dm2]` 块；嫌麻烦就用下面的方式 A。

### 方式 A：`install-mcp.js` 全局注册

由脚本代劳，**在 `<副本>` 目录下执行**：

```bash
node scripts/install-mcp.js --global --name=dev
```

它比方式 0 多做四件事：

1. **同时写 Claude Code 和 Codex**——`~/.claude.json` 和（检测到 `~/.codex/` 时）`~/.codex/config.toml`。用 `--codex` 强制、`--no-codex` 跳过。
2. **用 `--env=<名字>` 而不是绝对路径**——由 server 解析到标准 sessions 目录，**与当前工作目录无关**，副本搬家也不影响。
3. **把 `.env.example` 复制成 `<名字>.env`** 放到该去的位置。
4. **改 `~/.claude.json` 前先备份**成 `.bak-install-mcp`（那个文件里还有你其他所有 MCP 服务的配置）。

参数：`--name=dev` 决定 env 文件名与 server 标识 `adt-dev`（默认 `mysystem`）；`--exposition` 默认 `readonly,high`，见[第 9 节](#9-选择暴露哪些工具)。

生成的条目形如：

```json
"adt-dev": {
  "command": "node",
  "args": ["<副本绝对路径>/bin/mcp-abap-adt.js", "--env=dev", "--exposition=readonly,high"],
  "env": { "NODE_TLS_REJECT_UNAUTHORIZED": "0" }
}
```

### 方式 B：按工程注册

env 与 `.mcp.json` 都落在某个工程里，配置随工程走：

```bash
node scripts/install-mcp.js --target=/path/to/my-abap-project --name=dev
```

生成 `<工程>/env/dev.env` 与 `<工程>/.mcp.json`（已存在则合并，不覆盖 env）。

> **把 `env/` 加进该工程的 `.gitignore`——env 文件里有明文密码。**

### 怎么选

| 情况 | 用哪个 |
|---|---|
| 只用 Claude Code，一套系统 | 方式 0 |
| 用 Codex，或 Claude + Codex 都要 | 方式 A |
| 要连多套系统 | 方式 A（`--env=<名字>` 省去重复写绝对路径） |
| 配置要随工程走、进版本库（env 除外） | 方式 B |

---

## 7. 填连接信息

env 文件的位置取决于你走的路：

| 路线 / 方式 | 位置 |
|---|---|
| H 路 | `<root>/.hi/mcp/mcp-abap-adt/.env` |
| 方式 0 | 你自己指定的那个绝对路径 |
| 方式 A | macOS/Linux `~/.config/mcp-abap-adt/sessions/dev.env`；Windows `%USERPROFILE%\Documents\mcp-abap-adt\sessions\dev.env` |
| 方式 B | `<工程>/env/dev.env` |

```bash
SAP_URL=http://your-sap-host:8000
SAP_CLIENT=100
SAP_LANGUAGE=EN
SAP_SYSTEM_TYPE=onprem          # onprem | cloud | legacy
SAP_CONNECTION_TYPE=http        # http | rfc
SAP_AUTH_TYPE=basic             # basic | jwt
SAP_USERNAME=YOUR_USER
SAP_PASSWORD=your-password
NODE_TLS_REJECT_UNAUTHORIZED=0  # 自签证书时需要
```

**这个文件含明文密码，永远不要提交。** 其他认证方式（JWT / BTP 服务密钥 / 证书）见 [README 的「env 文件详细配置」](../../README.zh-CN.md#env-文件详细配置)。

> 只支持整行注释（`#` 开头），**不支持行内注释**。

### `SAP_LANGUAGE` 有副作用，值得知道

SAP 把**登录语言**当作新建对象的原始语言。本 server 会把 `SAP_LANGUAGE`（默认 `EN`）注入每一个请求，所以通过它创建的对象原始语言恒为该值，而同一个人在 SE11/SE80 手工建的对象跟随**他自己的**登录语言。想让两者一致，就把 `SAP_LANGUAGE` 设成团队实际使用的语言。

### 系统只能经 SAProuter 访问

SAP GUI 要填路由串（如 `/H/1.2.3.4/H/`）才能登录的系统，**HTTP 过不去，要走 RFC**：只放行 SAP 协议的 router（saprouttab 只有 `S` 条目）会拒绝裸 TCP 路由，而 HTTP 包在 SAP 协议里送到 ICM 后，ICM 的回复又会被 router 拒收。env 这样写：

```bash
SAP_URL=http://<应用服务器>:8000   # SAP Logon「应用服务器」一栏；端口不是 80XX 时另设 SAP_SYSNR
SAP_CONNECTION_TYPE=rfc
SAP_SAPROUTER=/H/1.2.3.4/H/
```

另需 SAP NW RFC SDK 和原生模块 `@mcp-abap-adt/sap-rfc-lite`，见 [RFC 安装](RFC_SETUP.md)。SDK 是 SAP 授权软件，**不要提交、不要放进发布包**。

完整步骤（安装、配置、注册、验证、常见问题）见 [经 SAProuter 连接说明](SAPROUTER_ZH.md)。

---

### 同一系统的多个 client

一个服务可以访问同一个系统的多个 client：

```
SAP_CLIENT=100
SAP_CLIENTS=100,800
# 可选，只有 800 用别的账号时才需要：
# SAP_CLIENT_800_USERNAME=...
# SAP_CLIENT_800_PASSWORD=...
```

配置后，每个工具都多一个可选参数 `sap_client`（取值 `"100"` 或 `"800"`），不传就用 `SAP_CLIENT`。
每个 client 各自一条连接，第一次用到时才登录；每次调用的结果末尾都有一行 `sap_client: <n>`，标明是哪个 client
给出的结果。`GetSession` 会列出已配置的 client，以及哪些已经连上。

注意：类、CDS、程序这些仓库对象是所有 client 共享的，用 `sap_client: "800"` 改一个类，改的就是同一个类。
如果 800 在 SCC4 里禁止修改仓库对象，SAP 的拒绝信息会原样返回。只支持 basic 认证；HTTP 和 RFC（包括经
SAProuter）都适用。

## 8. 重启并验证

配置**只在客户端启动时读取**。重启 Claude Code（和 / 或 Codex）。不需要手工启动 server——客户端会以 stdio 拉起它。

验证顺序，从最不可能出错的开始：

```
1. GetSession        → 返回 server_version / build_timestamp / started_at / pid
                       这一步只证明 server 起来了，还没碰 SAP
2. SearchObject      → object_name: "T100"
                       返回一行 T100 / TABL/DT / Messages / SDIC 即连接与授权正常
3. GetTableContents  → table_name: "T000", max_rows: 5
                       能读到数据即 Data Preview 通路正常
```

`GetSession` 的 `build_timestamp` 是**加载进内存的那个构建**（进程启动时冻结），不是磁盘上当前的文件。记录问题时带上它，就不会出现「你测的到底是哪个版本」这种争论。

---

## 9. 选择暴露哪些工具

`--exposition` 决定客户端能看到多少工具。工具定义本身要占上下文，**装完就固定支出**，与是否调用无关。

| 档位 | 工具数 | 适合 |
|---|---|---|
| `readonly` | 77 | 只读分析、代码审查 |
| `readonly,high`（默认） | 241（77 + 164） | 日常开发，读 + 写 + 激活 |
| `readonly,low` | 77 + 127 | 需要手工控制 lock / unlock / session 的场景 |
| `compact` | 27 | 上下文吃紧时；按对象类型路由的门面，覆盖 CRUD + 检查 + 分析 + 运行时 |

各档位的完整清单在 `docs/user-guide/AVAILABLE_TOOLS_<档位>.md`。

约束：`high` 与 `low` 互斥；`compact` **必须单独使用**，不能与其他档位组合。

改档位就是改客户端配置里那一行 `--exposition=`，然后重启客户端。

---

## 10. 连多个 SAP 系统

一个 server 进程 = 一个 SAP 系统。要连多套就注册多个条目，每个一份 env：

```bash
node scripts/install-mcp.js --global --name=dev
node scripts/install-mcp.js --global --name=qas
node scripts/install-mcp.js --global --name=prd
```

得到 `adt-dev` / `adt-qas` / `adt-prd` 三个 server，env 文件都在同一个 sessions 目录下。用方式 0 的话就多跑几次 `claude mcp add`，换 server 名和 `--env-path`。

**注意上下文成本是叠加的**：三个系统 × `readonly,high` ≈ 723 个工具定义常驻。生产系统建议只给 `readonly`，或整体改用 `compact`。

---

## 11. 更新

**规则只有一条：重新取包，然后重启客户端。** server 只在启动时加载 `dist/`，所以重装或重新编译对一个**已经在跑的进程完全不可见**。

按当初走的那条路选命令：

```bash
# H. Hi 平台 —— 就地更新并重写 .mcp.json
hi project init --root <绝对路径> --json

# A. 飞书 —— 安装器会自更新；依赖要重装一次，因为依赖清单可能变了
node install-skills.mjs --skill mcp-abap-adt
cd <副本> && npm install --omit=dev --ignore-scripts

# B. git clone
git pull && npm install && npm run build
```

**三条路都不需要重新注册**：A / B 注册的是一个路径，而该路径下的代码刚被替换；H 路的 `.mcp.json` 由 `hi project init` 重写。

**env 文件在三条路上都不会被动。** H 路更新时会读现有 `.env`，只把 `env_keys` 里缺的键以空值追加到末尾，已填的值一个都不改。

重启后用 `GetSession` 的 `build_timestamp` 确认新版本真的生效了。

---

## 12. 出问题时

### server 根本没出现（客户端里看不到 ABAP 工具）

1. 配置只在启动时读——确认**真的重启了客户端**，不是重开一个窗口
2. 在副本目录手工跑一次 `node bin/mcp-abap-adt.js --version`：
   - `Cannot find module '../dist/server/launcher.js'` → **`dist/` 不存在**。你是 git clone 装的，需要 `npm install && npm run build`（见[第 5 节](#5-路线-b从源码git-clone)）
   - `Cannot find module '@mcp-abap-adt/...'` → 生产依赖没装（见[第 4.2 节](#42-装运行时依赖不能跳)）
   - 编译报缺 `tsc` / `biome` → 装依赖时加了 `--omit=dev`，编译需要 devDependencies，重跑 `npm install`
3. 检查客户端配置里是不是**绝对路径**（`claude mcp add` 和 `.mcp.json` 都不接受 `~`）
4. `claude mcp list` 看条目在不在、命令对不对；H 路用 `hi mcp doctor --json`

### 连接失败

| 现象 | 原因 |
|---|---|
| `ENOTFOUND` | `SAP_URL` 主机名解析不了；先 `nslookup`，注意是否需要 VPN |
| 自签证书 TLS 报错 | env 里设 `NODE_TLS_REJECT_UNAUTHORIZED=0` |
| 404 且路径含 `/sap/bc/adt` | SICF 节点没激活，找 Basis |
| Kerberos 认证起不来 | H 路和 A 路的包不含 `kerberos` 原生二进制，走 B 路 |

### 权限不足的表现

读操作能跑、写操作报 403 或 SAP 自己的授权消息 → 缺 `S_DEVELOP` 对应活动。本 server 会把 SAP 的原话透传出来，照着那句话找 Basis 即可。

### 报错信息末尾的方括号

每条错误都带 `[mcp-abap-adt <版本>, built <时间>, pid <进程号>]`。反馈问题时连它一起贴——它说明是哪个构建、哪个进程回答的。

---

## 相关文档

- [README（中文）](../../README.zh-CN.md) — 完整功能与 env 字段说明
- [工具清单](../user-guide/AVAILABLE_TOOLS.md) — 全部工具及参数
- [认证与 destination](../user-guide/AUTHENTICATION.md) — JWT / BTP 服务密钥
- [RFC 安装](RFC_SETUP.md) — BASIS < 7.50 的 legacy 系统，以及只能经 SAProuter 访问的系统
- [经 SAProuter 连接说明](SAPROUTER_ZH.md) — 只能经 SAProuter 访问的系统，中文完整步骤
