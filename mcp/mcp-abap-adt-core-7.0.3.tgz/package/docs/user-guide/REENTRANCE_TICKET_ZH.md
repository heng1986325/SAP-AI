# S/4HANA Cloud：Reentrance Ticket 浏览器登录

`SAP_AUTH_TYPE=reentrance-ticket` 为 S/4HANA Cloud 提供浏览器 SSO 登录。支持 **stdio、Streamable HTTP 和 SSE**。本机模式在第一次调用 SAP 工具时打开浏览器；远程模式返回一次性登录入口，由用户在自己的浏览器完成 SSO/MFA。认证会话仅保存在进程内存。

启动 MCP、初始化协议和列出工具都不会打开浏览器。此方式不需要把 SAP 密码、JWT 或浏览器 Cookie 写入配置，也不需要安装 SAP `adt-ls`。

**当前统一使用 ADT reentrance-ticket 登录入口**，不再提供 Fiori Tools 流程分支，也不读取旧变量 `SAP_AUTH_REENTRANCE_FLOW`。已有配置可以删除该变量；保留旧变量也不会改变登录入口。

ADT 登录路径此前已在目标租户通过真实只读验收：2026-10-15 19:09:36（上海时间），浏览器登录、ADT discovery、完整系统信息及第二次 discovery 均成功，整个过程只打开一次浏览器并复用同一会话。该次运行发生在删除流程分支之前，使用本机回调；统一入口及本次 HTTP/SSE 改动未重新发起真实 SAP 登录。既有证据不证明远程 HTTPS 回调、对象写入或激活权限，也不代表所有租户都已验证。

本次编译、测试及租户尝试的结果见[验证记录](../development/tests/REENTRANCE_TICKET_VALIDATION.md)。

## 配置与构建

从当前源码目录安装依赖并构建，要求 Node.js 22 或更高版本：

```bash
npm ci --ignore-scripts
npm run build:fast
npm run test:unit
```

新增运行时依赖 `open` 用于打开本机浏览器，`tough-cookie` 用于管理会话 Cookie。`build:fast` 编译 TypeScript；`test:unit` 使用独立 Jest 配置，跳过会触发 SAP 认证的 integration `globalSetup`。

复制并填写 [配置示例](../installation/examples/reentrance-ticket.env.example)。以下域名均为占位示例，请将 `SAP_URL` 换成自己的租户 HTTPS 根地址；API 地址由程序发现，无须手动填写：

```dotenv
SAP_AUTH_TYPE=reentrance-ticket
SAP_URL=https://your-tenant.s4hana.sapcloud.cn
SAP_SYSTEM_TYPE=cloud
SAP_CONNECTION_TYPE=http
SAP_LANGUAGE=EN
SAP_AUTH_TIMEOUT_MS=180000
MCP_BROWSER=system
```

| 字段 | 行为 |
|---|---|
| `SAP_AUTH_TYPE` | 必须显式设为 `reentrance-ticket`；残留的 `SAP_JWT_TOKEN` 不会覆盖该模式。 |
| `SAP_URL` | 租户 HTTPS 根地址，不包含用户名密码、业务路径、查询参数或片段。UI/API 地址通过服务发现取得。 |
| `SAP_SYSTEM_TYPE` | 使用 `cloud`；不接受 `onprem` 或 `legacy`。 |
| `SAP_CONNECTION_TYPE` | 使用 `http`，指 MCP 进程到 SAP 的连接协议。MCP 对外可选择 stdio、HTTP 或 SSE。 |
| `SAP_CLIENT` | 可选；仅在已知目标 client 时填写。不推测默认 client。 |
| `SAP_LANGUAGE` | 可选；示例设为 `EN`，用作登录及 ADT 请求语言。 |
| `SAP_AUTH_TIMEOUT_MS` | 正整数毫秒，默认 `180000`，为浏览器登录保留 3 分钟。客户端工具超时也须足够长。 |
| `MCP_AUTH_TOKEN` | HTTP/SSE 必填的 MCP 访问令牌，至少 32 个 bearer-token 字符；不是 SAP 密码或票据，不能放进 URL。stdio 不使用。 |
| `SAP_AUTH_PUBLIC_URL` | HTTP/SSE 远程登录的公开 HTTPS 基地址，可含路径前缀；只有本机 loopback 调试可用 HTTP。省略时使用本机浏览器与 loopback 回调。 |
| `MCP_BROWSER` | 默认 `system`；可指定 `chrome`、`edge` 或 `firefox`。本机模式需要可交互浏览器；HTTP/SSE 配置 `SAP_AUTH_PUBLIC_URL` 后由用户打开登录入口，可使用 `headless`，不会启动服务器浏览器。 |

环境配置字段的优先级是：**显式选择的 env 文件 > 进程环境变量 > 自动发现的当前目录 `.env`**。指定 `--env-path` 后读取该文件，不再叠加当前目录 `.env`；未指定文件时，进程环境变量覆盖自动发现文件中的同名值。显式命令行选项 `--browser`、`--connection-type` 和 `--system-type` 分别覆盖环境配置中的浏览器、连接类型和系统类型，并按最终值校验是否受支持。

`SAP_CLIENTS` 的启动校验也遵循上述优先级，空值同样可以覆盖低优先级来源。例如，显式文件中的 `SAP_CLIENTS=` 可以清空 shell 残留；未指定文件时，shell 中的 `SAP_CLIENTS=` 可以清空自动发现的 `.env` 配置。高优先级来源定义了 client 列表后，不再继承低优先级来源的 `SAP_CLIENT_<n>_USERNAME/PASSWORD`。最终配置包含多个 client 时，票据模式会拒绝启动；使用 `MCP_ENV_PATH` 或 `--env` 选择的文件也属于显式指定。

`SAP_AUTH_TYPE=reentrance-ticket` 已足以选择本机浏览器票据认证。原流程选择项已删除，认证固定使用 ADT 入口，不发送 `scenario=FTO1`。这次简化保留原有 state、Cookie、CSRF 和身份校验，不改变 SAP 用户授权。

## Codex 本机 stdio 示例

用独立名称 `fr0ster-abap-adt-ticket` 配置该连接，保留已有连接条目。下例只开放两个初次验收工具，路径均须替换为真实绝对路径：

```toml
[mcp_servers.fr0ster-abap-adt-ticket]
command = "node"
args = [
  "/absolute/path/mcp-abap-adt/bin/mcp-abap-adt.js",
  "--transport=stdio",
  "--env-path=/absolute/path/s4hana-ticket.env",
  "--exposition=readonly"
]
startup_timeout_sec = 30
tool_timeout_sec = 300
enabled_tools = ["GetSession", "SearchObject"]
```

等价的进程启动命令是：

```bash
node /absolute/path/mcp-abap-adt/bin/mcp-abap-adt.js \
  --transport=stdio \
  --env-path=/absolute/path/s4hana-ticket.env \
  --exposition=readonly
```

stdio 需要 MCP 客户端发送请求，单独运行进程后没有浏览器窗口是正常现象。Codex 的 `startup_timeout_sec` 管启动，`tool_timeout_sec` 管工具调用；登录发生在工具调用中，因此示例把后者设为 300 秒。字段说明见 [OpenAI 官方 MCP 文档](https://learn.chatgpt.com/docs/extend/mcp?surface=cli)。本文只提供配置示例，不会修改 Codex 配置。

## HTTP / SSE 与 runtime 登录

每个进程绑定一套 SAP 配置；每个 MCP 协议会话拥有独立连接、Cookie、CSRF、身份和登录协调器。部署系统与预览系统应使用各自的 env 文件和服务实例。本次增加的是 MCP 传输与认证支持，尚未提供 Fiori OData HTTP 代理或单实例多 destination ticket 路由。

使用 [HTTP/SSE 配置示例](../installation/examples/reentrance-ticket-http.env.example)，填写普通 SAP 系统地址和 `MCP_AUTH_TOKEN`。可以用 `node -e "process.stdout.write(require('node:crypto').randomBytes(32).toString('hex'))"` 生成访问令牌，将其交给受信任的 MCP 客户端或 runtime 网关；不要提交配置文件。

```bash
# Streamable HTTP
node bin/mcp-abap-adt.js --transport=http --host=127.0.0.1 --port=3000 \
  --env-path=/absolute/path/s4hana-ticket-http.env --exposition=readonly

# 或 SSE，使用另一端口
node bin/mcp-abap-adt.js --transport=sse --host=127.0.0.1 --port=3001 \
  --env-path=/absolute/path/s4hana-ticket-http.env --exposition=readonly
```

客户端向 MCP 接口发送 `Authorization: Bearer <MCP_AUTH_TOKEN>`。HTTP 默认接口是 `/mcp/stream/http`；SSE 是 GET `/sse` 和 POST `/messages`，两条路由都需要鉴权。`/mcp/health` 也需要相同鉴权。网络 token 单独校验，不会进入 SAP connection 的配置或转发到 SAP。

HTTP 使用 SDK 的有状态协议：初始化返回 `Mcp-Session-Id`，后续请求须携带它，结束时发送 DELETE。标准 MCP SDK 客户端会处理该机制。SSE 须保持原连接，POST 使用 SDK 给出的 sessionId。不要每次工具调用重新初始化 MCP，否则会创建新的 SAP 登录会话。默认最多 32 个协议会话，闲置 30 分钟清理；HTTP 单次响应结束不会清理 SAP 会话，SSE 断开、HTTP DELETE、超时和进程关闭会清理对应状态。

### 本机网络客户端

不设置 `SAP_AUTH_PUBLIC_URL` 时，仅允许 loopback 监听，第一次 SAP 工具调用仍在服务器所在电脑打开浏览器。初始化、列工具、ping 和 health 不发起 SAP 登录。本机首次工具调用应保留足够的登录超时。

### 远程 runtime

例如配置 `SAP_AUTH_PUBLIC_URL=https://adt.example.com/runtime-a` 后，公开入口及参数为：

| 步骤 | 地址与行为 |
|---|---|
| MCP 工具首次需要登录 | 返回 `https://adt.example.com/runtime-a/auth/login/<一次性随机标识>`；不会执行原业务 handler，也不会输出完整 SAP 登录 URL、callback URL 或票据。 |
| 用户打开入口 | MCP 设置本次登录专用的 HttpOnly / SameSite=Lax 浏览器 Cookie，HTTPS 时带 Secure，再重定向到发现的 SAP UI origin。 |
| SAP 登录 | 使用 `/sap/bc/adt/core/http/reentranceticket`；`redirect-url` 指向公开基地址下的 `/adt/redirect`，携带随机 `state`，另按需传 `sap-client`、`sap-language`。不发送 FTO1。 |
| SAP 回调 | 校验 GET、路径、完整 state、浏览器关联 Cookie 和唯一票据；兼容已验证的 ADT 第二个问号边界形式。只消费一次，过期/取消/重放均拒绝。 |
| 兑换和身份核验 | 仍只向该目标自动发现的 API origin 发送票据，验证 ADT discovery 和完整身份。浏览器的“票据已接收”页面不代表兑换已经成功。 |
| 用户重试原 MCP 工具 | 在同一 MCP 会话内使用认证结果；认证就绪后才执行工具。原先返回登录入口的调用不会在后台执行业务操作。 |

反向代理应将 MCP 路由与 `/runtime-a/auth/login/*`、`/runtime-a/adt/redirect` 转发到同一个实例，并保留配置的公开 Host。SSE 需要关闭代理响应缓冲。仅登录入口和 SAP 回调通过一次性关联机制访问，其余 MCP 路由仍需 Bearer。反向代理应关闭登录路径的 access log 或删除完整 URL/query，不能记录票据、关联 Cookie、MCP token 或一次性入口。

`SAP_AUTH_PUBLIC_URL` 必须来自可信服务配置，不从请求 Host 或 forwarded headers 推导。远端仅接受 HTTPS 公共地址；服务本身可使用现有 `--tls-cert/--tls-key`，或在受控反向代理处终止 TLS。非 loopback 监听必须提供此公共地址。

同一个服务 token 代表同一受信任调用方；它不是平台用户身份或细粒度 RBAC。runtime 应先验证平台用户，再选择其专用实例/访问令牌，不能只凭客户端自报用户 ID 分配 SAP 会话。`x-sap-*` 和 destination 切换头在 ticket 网络模式明确拒绝。

远程模式中，工具执行期间遇到 SAP 会话失效会返回错误，不弹服务器浏览器、不自动重放业务请求。下一次工具调用在执行前发起登录，并返回新的入口；普通权限 403 不触发重登录。登录超时后须由下一次用户调用发起新尝试。

**租户验收边界：**HTTP/SSE 与公开回调处理通过本地模拟测试，不等于目标 SAP 租户已经允许该 HTTPS `redirect-url`。此前真实成功证据仅覆盖本机回调。部署 runtime 前应由用户完成一次真实登录、ADT discovery、系统信息及第二次只读请求，确认远程回调可接受及会话复用。如果 SAP 拒绝公开 callback，不删除 state 或浏览器关联校验绕过。

## 本机完整登录流程

以下时序对应当前唯一的 ADT 登录流程。UI origin 用于浏览器交互认证，API origin 用于票据兑换和后续 ADT 请求；二者均由 SAP 返回。

```mermaid
sequenceDiagram
    participant C as Codex MCP 客户端
    participant M as 本机 MCP 服务
    participant B as 系统浏览器
    participant U as SAP UI 与 SSO
    participant A as SAP API
    C->>M: 初始化及 tools/list
    M-->>C: 返回工具列表，不登录
    C->>M: 首次 SAP 工具调用
    M->>U: GET /sap/public/bc/icf/virtualhost
    U-->>M: HTTPS UI/API 地址
    Note over M: 创建 loopback 回调、随机端口及 state
    M->>B: 打开 ADT reentranceticket 登录地址
    B->>U: 用户完成 SSO/MFA
    U-->>B: 重定向到本机回调
    B->>M: 返回 state 和一次性 ticket
    Note over M: 验证回调，只消费一次，关闭监听
    M-->>B: 提示回调完成
    M->>A: GET discovery，携带 MYSAPSSO2 和 Fetch
    A-->>M: ADT XML、会话 Cookie、CSRF
    Note over M: 释放 ticket，内存保存会话
    M->>A: 使用会话读取系统信息
    A-->>M: system ID、user、client
    M->>A: 使用同一连接执行首个工具
    A-->>M: 工具结果
    M-->>C: 返回工具结果
    C->>M: 后续 SAP 工具调用
    M->>A: 复用内存会话
    A-->>M: 工具结果
    M-->>C: 返回工具结果
```

1. **启动并选择认证方式。** 启动器读取配置，在 AuthBroker 初始化前识别 ticket 模式，创建对应传输的 ticket 服务并复用现有工具、权限控制和审计。启动、MCP 初始化及 `tools/list` 均不触发 SAP 登录。
2. **发现 UI/API 地址。** 首次工具调用请求 `/sap/public/bc/icf/virtualhost`，读取并验证响应中的 HTTPS UI/API origins，不通过拼接 `-api` 猜测地址。浏览器登录使用返回的 UI origin，票据兑换及后续 ADT 请求使用返回的 API origin。
3. **准备本机回调。** 创建仅监听 loopback 的随机端口服务，生成 256 位随机 `state`，设置登录超时。ADT 流程使用 `/adt/redirect`；`redirect-url` 包含这个本机地址和 `state`，并由 URL 参数编码后传给 SAP。
4. **打开浏览器登录。** 浏览器访问 UI origin 下的 `/sap/bc/adt/core/http/reentranceticket`，由用户完成 SSO/MFA。若配置了 client 或语言，则一并传入相应参数；不猜测默认 client。
5. **接收并核验回调。** SAP 引导浏览器返回本机。服务校验 GET 方法、回调路径、唯一且完整匹配的 `state`，再接收唯一、有效的 `reentrance-ticket`；一次请求只消费一次回调。成功回调后关闭本机监听。浏览器的完成提示仅表示收到有效回调，后续 API 兑换仍可能失败。
6. **一次性兑换票据。** 向 API origin 的 `/sap/bc/adt/discovery` 发起一次 GET，发送 `MYSAPSSO2: <ticket>`、`x-sap-security-session: create` 和 `x-csrf-token: Fetch`。必须收到 HTTP 200、有效 ADT discovery 内容、会话 Cookie 和 CSRF；HTTP 200 的 HTML 登录页不算成功。兑换后立即释放 ticket。
7. **初始化并固定身份。** 使用刚建立的同一连接读取系统信息，取得完整的 system ID、用户名和 client，并固定为该连接的身份基准。信息缺失时首个业务工具不执行，也不借用残留 Basic/JWT 配置里的身份。
8. **执行工具并复用会话。** 完成初始化后才执行首个工具。后续工具通过同一连接发送会话 Cookie，按需携带 CSRF，并保留原有锁和 stateful/stateless 请求行为；不继续发送 ticket，也不为每次调用重新打开浏览器。
9. **处理过期和退出。** 认证过期的恢复只由实际请求触发；并发请求共用一次登录。GET/HEAD 最多登录并重试一次，写请求不自动重放，普通权限 403 不触发登录。重新认证必须验证身份仍与初始值一致。超时、取消和进程关闭会清理回调；进程退出或重启后内存会话不再保留。

### 完整请求地址及参数

本次已知租户的 UI origin 为 `https://your-tenant.s4hana.sapcloud.cn`，服务发现返回的 API origin 为 `https://your-tenant-api.s4hana.sapcloud.cn`。虽然这两个域名在文字上相差 `-api`，实现仍以 `relatedUrls.UI`、`relatedUrls.API` 的返回值为准，**不从 UI 域名推导 API 域名**。

| 顺序 | 发起方与方法 | 完整基础地址 | Query、请求头及用途 |
|---|---|---|---|
| 1 | MCP → SAP，GET | `https://your-tenant.s4hana.sapcloud.cn/sap/public/bc/icf/virtualhost` | 无登录 query；发送 `Accept: application/json`。从 `relatedUrls.UI` 和 `relatedUrls.API` 读取 HTTPS 地址，取其 origin。 |
| 2 | 浏览器 → SAP UI，GET | `https://your-tenant.s4hana.sapcloud.cn/sap/bc/adt/core/http/reentranceticket` | Query 包含 `redirect-url`；配置了 client 或语言时增加 `sap-client`、`sap-language`。不发送 `scenario`。由浏览器完成 SSO/MFA。 |
| 3 | 浏览器 → 本机，GET | `http://localhost:<port>/adt/redirect` | `<port>` 是本次登录创建的 loopback 随机端口。回调 query 包含原 `state` 与 SAP 返回的 `reentrance-ticket`；这里只展示基础地址，不记录真实完整回调。 |
| 4 | MCP → SAP API，GET | `https://your-tenant-api.s4hana.sapcloud.cn/sap/bc/adt/discovery` | Query 按配置增加 `sap-client`、`sap-language`。一次性 ticket 放在 `MYSAPSSO2` 请求头；同时发送 `x-sap-security-session: create`、`x-csrf-token: Fetch`。 |
| 5 | MCP → SAP API，GET | `https://your-tenant-api.s4hana.sapcloud.cn/sap/bc/adt/core/http/systeminformation` | Query 包含 `_=<当前毫秒时间戳>`，用于避免缓存；按配置补充 `sap-client`、`sap-language`。发送会话 Cookie 及 `Accept: application/vnd.sap.adt.core.http.systeminformation.v1+json`，不再发送 ticket。 |

各参数的含义和边界：

| 参数或值 | 所在位置 | 构造与校验 |
|---|---|---|
| `redirect-url` | 浏览器访问 ADT 登录入口的 query | 值是本机回调地址，并已含 `state`。它作为**一个完整参数值**交给 `URLSearchParams.set()` 编码；其中 `:`、`/`、`?`、`=` 被自动转义。不要先手动编码再交给 `URLSearchParams`，否则会重复编码。 |
| `state` | 嵌套在 `redirect-url` 内，随后由 SAP 回调带回 | 每次登录用 32 个随机字节生成 **64 位十六进制字符串**，即 256 位 nonce。不是 SAP 用户、client、票据或持久配置；本机必须收到唯一且完整匹配的值。 |
| `sap-client` | 登录入口及 API 请求的 query | 来自可选的 `SAP_CLIENT`。未配置则不发送，不推测默认 client。 |
| `sap-language` | 登录入口及 API 请求的 query | 来自可选的 `SAP_LANGUAGE`，示例为 `EN`。未配置则不发送。 |
| `reentrance-ticket` | SAP 返回本机的 callback query | SAP 生成的不透明一次性票据，示意为 `<opaque-ticket>`。它与 `state` 不同；由本机解析并消费，不由用户填写。 |
| `MYSAPSSO2` | 第一次 API discovery 的 HTTP 请求头 | 值是刚收到的 `<opaque-ticket>`。**不是 discovery 的 query 参数，也不是再次发送 callback URL**。兑换成功后释放，不用于后续 ADT 调用。 |
| `x-sap-security-session` / `x-csrf-token` | 第一次 API discovery 的 HTTP 请求头 | 分别传 `create`、`Fetch`，请求安全会话与 CSRF token。成功响应的会话 Cookie 和 CSRF 保存在进程内存；后续按请求需要使用。 |
| `_` | systeminformation 的 query | `Date.now()` 的毫秒时间戳，仅用于避免缓存，不是 state 或凭据。 |

浏览器登录 URL 的**结构模板，不可直接打开**如下。`<port>` 和 `<state>` 只是阅读用占位符，不是真实端口或 nonce；模板不含 ticket：

```text
https://your-tenant.s4hana.sapcloud.cn/sap/bc/adt/core/http/reentranceticket?redirect-url=http%3A%2F%2Flocalhost%3A<port>%2Fadt%2Fredirect%3Fstate%3D<state>&sap-language=EN
```

`redirect-url=` 后的编码片段是一个完整的本机回调参数值；外层的 `&sap-language=EN` 属于 SAP 登录请求，不属于回调。若配置 `SAP_CLIENT`，同样在外层增加 `&sap-client=<client>`；未配置时整个参数省略。实际代码使用真实运行时变量调用 `URLSearchParams` 一次编码，而不是手工替换或打开这条模板。

下面只展示构造过程；`port`、`state`、`client`、`language` 都是运行时变量，不在文档中填入真实回调或票据，也不输出生成的地址：

```js
// port: 本次 loopback 监听端口；state: 本次随机生成的 64hex nonce。
// uiOrigin 来自 virtualhost 的 relatedUrls.UI，此处展示已知公开域名。
const uiOrigin = 'https://your-tenant.s4hana.sapcloud.cn';
const redirect = new URL('/adt/redirect', `http://localhost:${port}`);
redirect.searchParams.set('state', state);

const loginUrl = new URL('/sap/bc/adt/core/http/reentranceticket', uiOrigin);
loginUrl.searchParams.set('redirect-url', redirect.toString());
if (client) loginUrl.searchParams.set('sap-client', client);
if (language) loginUrl.searchParams.set('sap-language', language);
// 将 loginUrl.toString() 交给浏览器打开；不记录该地址。
```

嵌套的 `redirect-url` 经过一次参数编码；SAP 返回后，callback 的普通查询参数由 URL 解析器解码一次。ticket 始终按不透明值传给 `MYSAPSSO2`，不能自行再次解码、截取或拼进 API URL。

### 历史两次报错分别发生在哪里

| 阶段与错误 | 已确认的原因 | 处理结果 |
|---|---|---|
| 旧 Fiori Tools 分支（现已移除）：`APS_SEC_LGN_COMMON(002)`，`redirect-url` 不合法 | SAP 在校验回调地址时拒绝了该次带 `state` 的 `/redirect` 地址，尚未进入票据兑换。官方 Fiori Tools 示例不带 `state`；SAP 未返回具体拒绝规则，因此不能推断所有查询参数或随机端口都被禁止。 | 当时改用官方 ADT 入口及 `/adt/redirect`，继续保留关联校验；增加超时时间不能修复该参数错误。当前程序固定使用 ADT。 |
| ADT：`No matching login request` | 浏览器已经回到本机，但 SAP 用第二个 `?` 追加参数，普通 URL 解析把部分后续参数并入 `state`，导致本地完整匹配失败。 | 在严格条件下规范化一个分隔符，再执行完整校验；修复后真实租户验证通过。 |

ADT 适配仅在 GET 和精确的 `/adt/redirect` 路径下生效：原始 query 必须以 `?state=` 开始，完整 64 位十六进制 nonce 必须通过 `timingSafeEqual`，且紧随其后的字符必须是字面量 `?`，才将这个精确边界上的一个 `?` 改为 `&`。随后继续要求唯一 state、完整匹配、唯一有效 ticket 和单次消费；错误、截短、扩展或重复的 nonce 仍被拒绝。

历史中的 `FTO1` 是 SAP 官方 Fiori Tools 使用的登录场景标识。当前程序不再发送 `scenario`，旧端点和分支也已移除。完整历史和删除分支前的脱敏成功证据见[验证记录](../development/tests/REENTRANCE_TICKET_VALIDATION.md)。

## 会话保存与账号切换

ticket、Cookie、CSRF 和完整回调 URL 不写入日志、工具输出或文件；会话只保存在当前 MCP 进程内存。关闭或重启进程后，下一次工具调用重新发起登录。浏览器已有的 SSO 状态可能简化交互，但本服务不读取或保存浏览器 Cookie。

**切换 SAP 账号时须创建新的 MCP 会话。** stdio 通过重启进程完成；HTTP 结束原协议会话（DELETE）后重新初始化，SSE 关闭原连接后重新连接。浏览器切换账号不会自动替换已建立的 ADT 会话；不要将失效恢复流程当作账号切换功能。新的 MCP 会话在浏览器中使用预期账号完成登录，同一会话内的重登录必须保持原身份。

同一 MCP 会话的并发首次调用共用一次登录，不同会话分别登录。本机模式认证失效时，GET/HEAD 最多重新登录并重试一次；远程模式在下一次工具调用的执行前返回登录入口，原业务请求不自动重放。写请求均不自动重放。普通权限 403 直接返回错误，不通过重复登录绕过权限判断。服务保持 TLS 校验，认证请求不携带凭据跟随跨域重定向。

## 验收与支持边界

构建完成后，可以先运行不登录的启动检查。该命令通过真实 MCP 启动器初始化并列出工具，不应打开浏览器：

```bash
node tools/reentrance-ticket-smoke.mjs \
  --env-path=/absolute/path/s4hana-ticket.env \
  --list-only
```

以下 smoke 脚本针对本机 stdio。完整只读 smoke 会打开浏览器，等待用户完成登录，然后依次读取 ADT discovery、系统信息和第二次 discovery：

```bash
node tools/reentrance-ticket-smoke.mjs \
  --env-path=/absolute/path/s4hana-ticket.env
```

也可使用 `--url=https://your-tenant.s4hana.sapcloud.cn` 做独立检查；该选项会清除继承的 SAP 连接配置，直接使用统一的 ADT 登录入口。需要指定 client、语言或超时时，使用 `--env-path` 文件。对其他租户应替换为相应 HTTPS 根地址。

完整 smoke 仅在两次 discovery 均返回 HTTP 200 和 ADT XML、系统信息包含 system/user/client、且整个过程仅打开一次登录浏览器后输出 `passed: true` 和 `session_reused: true`。`--list-only` 的 `passed: true` 仅表示 MCP 启动及工具列表检查通过。失败时进程以非零状态退出，不输出通过报告；脚本不进行对象搜索或 SAP 写入。

脚本辅助逻辑可单独离线检查，不会访问 SAP 或打开浏览器：

```bash
node --test tools/reentrance-ticket-smoke.test.mjs
```

初次验收只做以下读取：

1. 确认 MCP 初始化和 `tools/list` 成功，且此时没有登录窗口。
2. 调用 `GetSession`，在浏览器完成登录。检查工具成功返回及服务报告 ADT 会话已建立；浏览器出现登录页或仅完成回调都不单独构成 ADT 成功证据。
3. 对一个已知可读对象调用 `SearchObject`，确认实际 SAP 响应；在同一进程再次读取，确认不重复打开浏览器并继续收到 SAP 响应。
4. 分别记录本地测试结果、真实登录结果、首次读取及会话复用结果。`GetSession` 本身的本地会话 ID 不能代替第二次实际 SAP 读取。

只读验证仅证明已测身份、端点和资源的访问能力，不证明创建、更新、删除、激活或业务写入权限。后续使用原有 ADT 工具仍受目标系统授权和 Cloud 能力限制。

| 首版边界或失败 | 处理方式 |
|---|---|
| HTTP/SSE、远程登录 | 已有实现；需要 MCP Bearer 访问令牌。远程登录需公开回调配置及租户验收，仍由用户完成 SSO/MFA，不是无人值守认证。 |
| RFC、service-key/destination `--mcp` | 不与 ticket 模式组合；Basic/JWT 及原有 service-key 路径继续使用各自配置。 |
| `DeletePackage(force_new_connection=true)` | ticket 模式明确拒绝，不调用旧连接工厂，也不静默复用旧连接伪装新连接。 |
| Cloud PROGRAM 操作 | 按原有 Cloud 能力限制拒绝，包括 compact 路由。 |
| 回调缺失或不匹配 `state` | 不接受该回调；租户不接受含关联值的 callback 时不降级为无校验登录。最终返回失败或超时。 |
| `APS_SEC_LGN_COMMON(002)`、`redirect-url` 不合法 | SAP 拒绝了回调地址，票据兑换尚未开始。本次记录中的该错误来自已移除的 Fiori Tools 分支；若当前 ADT 入口也报告此错误，应确认该租户的回调规则。增加等待时间不能修复参数校验失败。请勿发送完整回调 URL。 |
| `No matching login request` | 本机拒绝了回调的方法、路径或 state。使用当前 ADT 修复版本并重新发起登录，勿复用旧窗口；若仍失败，只提供错误代码和提示，不提供地址栏或票据。 |
| 浏览器无法打开、用户未完成登录、回调缺票据 | 返回明确错误或超时；确认本机浏览器、租户登录及网络情况后重新发起工具调用。 |
| HTTP 200 实际返回 HTML 登录页 | 视为认证未完成，不当成 ADT 成功。 |
| API 返回权限 403 | 检查该用户的目标资源授权；登录成功不等于获准访问所有 ADT 资源。 |

## 协议来源

早期已移除的 Fiori Tools 分支及票据兑换协议参考 SAP 官方 `open-ux-tools`：

- [浏览器 reentrance-ticket 流程与 FTO1](https://github.com/SAP/open-ux-tools/blob/main/packages/axios-extension/src/auth/reentrance-ticket/index.ts)
- [MYSAPSSO2 与安全会话建立](https://github.com/SAP/open-ux-tools/blob/main/packages/axios-extension/src/auth/index.ts)
- [SAP/open-ux-tools Apache License 2.0](https://github.com/SAP/open-ux-tools/blob/main/LICENSE)

ADT 流程的端点与回调路径依据：

- [SAP KBA 3259196](https://userapps.support.sap.com/sap/support/knowledge/en/3259196)
- SAP 官方 ADT 3.60.3 插件：[destinations](https://tools.hana.ondemand.com/latest/plugins/com.sap.adt.destinations_3.60.3.jar)、[communication](https://tools.hana.ondemand.com/latest/plugins/com.sap.adt.communication_3.60.3.jar)。静态分析用于核对协议端点和回调路径；附带 `state` 的回调兼容性及查询参数边界适配，由删除流程分支前的真实租户验证确认。

本功能按协议独立实现，不将 SAP 项目源码或 ADT 插件作为运行时依赖。若后续直接复制或改编 SAP 源码，应保留相应版权、许可及适用的 NOTICE。
