# Reentrance Ticket 验证记录

发布文档中的租户域名已替换为 `your-tenant` 占位值；历史时间、响应状态和验收结论保持原记录。示例命令须先填写实际租户地址。

## 2026-10-16：HTTP/SSE 实现与离线验证

本次在 `7.0.3` 工作区增加专用的有状态 Streamable HTTP / SSE ticket 服务，共用延迟认证核心。每个 MCP 协议会话分别持有 SAP 连接、Cookie、CSRF、身份和工具上下文；Basic/JWT 原入口保留。

新增远程登录入口：配置 `SAP_AUTH_PUBLIC_URL` 后，首次工具调用返回一次性入口，用户在自己的浏览器完成登录，服务器不启动浏览器。回调只继续票据兑换与系统身份初始化，**不会在后台执行先前返回登录提示的业务 handler**；用户须在原 MCP 会话中重试工具。

本地验证使用真实 MCP SDK 客户端、真实 HTTP/SSE listener 和隔离的子进程启动器。SAP 响应由测试替身提供；全部单元测试使用 `jest.unit.config.cjs`，未加载 SAP integration `globalSetup`。

| 检查 | 结果 |
|---|---|
| `npm run build:fast` | 通过，生产 TypeScript 编译成功。 |
| `npm run test:check` | 通过，测试 TypeScript 检查成功。 |
| `npm run test:unit` | 75 个套件、872 个测试全部通过，包含 2 个真实连接类的离线端到端用例。 |
| `node --test tools/reentrance-ticket-smoke.test.mjs` | 6 个测试通过。 |
| `npm run lint:check` | 退出码 0；0 errors，1455 warnings、7 infos。仓库仍有既有 lint 警告。 |
| `git diff --check` | 通过。 |
| 编译后 stdio 入口 `--list-only` | 通过，76 个工具，`login_during_list: false`；使用 `.invalid` 测试地址，无 SAP 请求。 |

新增覆盖包括：

- 实际 HTTP/SSE 启动、SDK 初始化 / list / ping 无登录副作用，Bearer 鉴权，Host/Origin 校验与固定目标限制。
- HTTP 单次响应结束后保留会话，DELETE 释放；SSE 断开、空闲超时、服务器关闭时释放，接收请求体期间过期不会继续调用工具。
- 不同 MCP 会话分别创建 handlers registry、连接和 AsyncLocalStorage 身份上下文；初始化与登录各自只执行一次。
- 远程入口、浏览器 Cookie、state、单次消费、延迟超时、取消、重放拒绝，包含 `sap-client` 和第二个 `?` 的 ADT 回调。
- 真实 SDK → HTTP 服务 → 真实连接类 → 模拟 SAP HTTP 响应的完整链路：自动地址发现、一次票据兑换、真实系统信息解析、两会话各自的 Cookie/CSRF、第二次读取复用；不替换系统信息查询函数。
- 远程认证只发生在工具执行前；请求中的 401 或跨域 IdP 重定向不会自动重放，下一次工具调用可以重新登录；普通 403 不触发登录。
- 登录入口不写审计日志，票据与会话凭据不进入工具返回；既有 stdio、Basic/JWT 和 Cloud 限制回归。

**当前验收边界：**没有启动真实 SAP 登录，没有访问 SAP 或修改对象，没有部署到远程 runtime，没有替换全局 MCP 配置。真实 SAP 证据仍只来自下面的历史本机 ADT 流程。目标租户是否允许公开 HTTPS `redirect-url`，须在部署环境完成浏览器登录、discovery、系统信息及第二次只读请求后确认。

使用说明与配置见[中文登录文档](../../user-guide/REENTRANCE_TICKET_ZH.md)和[HTTP/SSE 示例](../../installation/examples/reentrance-ticket-http.env.example)。本次不包含 OData 预览代理或单进程多 SAP destination ticket 路由。

## 2026-10-15：本机 ADT 流程与历史验收

日期：2026-10-15。基于本仓库 `7.0.3`、起始提交 `96dd7502` 实现，未发布或替换现有 MCP 配置。

**当前实现已统一为 ADT 登录，移除 Fiori Tools 分支，不再读取 `SAP_AUTH_REENTRANCE_FLOW`。** 统一入口后的编译、787 个单元测试、6 个 smoke 脚本测试和不登录的生产入口检查均通过；本次没有重新发起真实 SAP 登录。

保留的真实 SAP 证据来自删除流程分支之前：ADT 登录在 `2026-10-15T11:09:36.090Z`（上海时间 19:09:36）通过目标租户的登录、只读 ADT 访问和会话复用验收。该记录不能表述为统一入口后重新进行的真实验收，也不证明对象创建、修改、删除、激活或其他业务写入权限。

## 排障过程

| 步骤 | 实际到达的阶段 | 观察到的证据 | 处理及结论边界 |
|---|---|---|---|
| 1. 旧 `fiori-tools` / FTO1 分支（现已移除） | SAP 服务端校验 `redirect-url`，尚未收到本机有效回调。 | 浏览器显示 `APS_SEC_LGN_COMMON(002)`、`redirect-url` 不合法；本机随后等待 180 秒超时。 | 确认该次失败发生在 SAP 的回调地址校验阶段。**具体拒绝规则未知**：不能据此断言是 `state`、查询参数、路径或某种 localhost 格式被 SAP 普遍禁止；延长超时不能修复已经发生的参数拒绝。 |
| 2. 当时切换到 ADT 登录 | SAP 已重定向到 `/adt/redirect`；本机执行完整 `state` 校验。 | 本机显示 `No matching login request`。脱敏结构诊断为原始解析 state 长度 89、完整预期 64 位十六进制 nonce 前缀存在、包含第二个 `?`、ticket 数量 1。 | 该次 ADT 回调追加参数时使用第二个 `?`，使解析后的 state 混入后续参数，因而未通过本地完整值校验。这与步骤 1 的 SAP 参数拒绝属于不同阶段，不能合并解释为同一错误。 |
| 3. 适配 ADT 回调查询边界后重试 | 本地关联校验、票据兑换、真实 ADT 读取及会话复用。 | 两次 discovery 均 HTTP 200 且为 ADT XML；系统信息三字段存在；浏览器打开 1 次，`session_reused: true`、`passed: true`。 | 仅在 ADT 指定回调路径、完整 nonce 通过 `timingSafeEqual` 后，将精确边界处的第二个 `?` 改为 `&`；原有单一 state、匹配值、单一 ticket 和单次消费校验继续执行。该目标租户的只读流程通过，未验证 SAP 写入权限。 |

表中记录的是删除流程分支前，该目标租户的实际响应及排障过程，不是 SAP 对所有系统的通用回调规则。当时通过 `SAP_AUTH_REENTRANCE_FLOW=adt` 选择 ADT 端点，保留关联校验并适配参数边界后才取得真实成功证据。**当前已删除这个选择项和 Fiori Tools 分支，固定使用 ADT 入口；旧变量即使存在也不再被读取。**

## 本地检查

以下为统一 ADT、删除流程选择项后的最终本地复核结果。没有运行 SAP integration 登录或重新进行真实 SAP 读写。

| 检查 | 结果 |
|---|---|
| `npm run build:fast` | 通过，生产 TypeScript 编译成功。 |
| `npm run test:check` | 通过，测试代码 TypeScript 检查成功。 |
| `npm run test:unit` | 68 个测试套件、787 个测试全部通过；使用 `jest.unit.config.cjs`，未加载 SAP integration `globalSetup`。 |
| `node --test tools/reentrance-ticket-smoke.test.mjs` | 6 个测试全部通过。 |
| `npm run lint:check` | 退出码 0；0 errors，1455 warnings、7 infos。仓库仍有既有 lint 警告。 |
| 本次 8 个修改 src 文件的 Biome 检查 | `diagnostic-level=error` 检查通过。 |
| `git diff --check` | 通过。 |

离线测试覆盖地址发现、编码后的浏览器 URL、loopback/state/单次回调、超时和取消、票据兑换、Cookie 更新删除、CSRF、并发登录、有限 GET/HEAD 恢复、写请求不重放、权限 403、身份固定、锁定/写入/解锁请求的会话一致性、凭据脱敏、Cloud PROGRAM 限制与 Basic/JWT 兼容行为。

统一入口前曾有 68 个套件、802 个单元测试和 6 个 smoke 测试通过。当前 787 的数量反映已删除双流程分支的重复用例，并增加旧流程变量不再影响配置的回归测试；历史数量不作为本次最终检查结果。

入口测试启动真实 stdio 子进程，覆盖三类配置来源、CLI 覆盖、残留 JWT、无登录的 `tools/list`、不支持的 transport/RFC/destination。服务测试另通过真实 `StdioServerTransport` 验证 stdin EOF 时取消登录和释放连接。

## 编译后入口检查

统一入口后通过独立 MCP 客户端执行以下命令，未提供旧流程选择变量；生产入口直接使用 ADT 模式，初始化及列出工具均未打开浏览器：

```bash
node tools/reentrance-ticket-smoke.mjs \
  --url=https://your-tenant.s4hana.sapcloud.cn \
  --list-only
```

```json
{
  "timestamp": "2026-10-15T11:28:08.883Z",
  "transport": "stdio",
  "tool_count": 76,
  "login_during_list": false,
  "passed": true
}
```

该结果只证明编译后服务可以初始化并列出工具，不证明 SAP 登录或 ADT 权限。

## 历史真实租户只读验证（删除流程分支前）

在当时的独立测试进程中显式配置 `SAP_AUTH_REENTRANCE_FLOW=adt`，取得以下脱敏结果摘要。该变量现已删除，此处仅保留运行历史。该进程使用仅含 2 个只读探针工具的专用 registry；上面的 76 个工具来自当前生产入口 `tools/list`，两者分别记录历史登录读取与本次生产入口启动，不能合并为本次重新登录的证据：

```json
{
  "timestamp": "2026-10-15T11:09:36.090Z",
  "transport": "stdio",
  "reentrance_flow": "adt",
  "tool_count": 2,
  "discovery": {
    "http_status": 200,
    "discovery_xml": true,
    "read_number": 1
  },
  "system_information": {
    "system_id_present": true,
    "user_present": true,
    "client_present": true
  },
  "repeated_discovery": {
    "http_status": 200,
    "discovery_xml": true,
    "read_number": 2
  },
  "browser_openings": 1,
  "session_reused": true,
  "passed": true
}
```

浏览器完成认证和回调后，票据成功兑换为 ADT 会话；首次及重复 discovery 均返回 HTTP 200 和 ADT XML，系统信息包含 system、user、client，且未重复打开浏览器。报告只记录字段是否存在，不记录真实用户身份、系统标识或凭据。此次没有创建、修改、删除或激活 SAP 对象。

当前配置只需 `SAP_AUTH_TYPE=reentrance-ticket` 选择固定的 ADT 浏览器认证。旧流程变量已不生效；以下 Fiori Tools 失败仅属于现已移除的历史分支。

### 历史：已移除的 Fiori Tools 分支失败

当时使用旧版本默认的 `fiori-tools` 流程，对用户指定的 S/4HANA Cloud 租户发起一次独立测试进程中的浏览器登录。浏览器打开后，180 秒内未收到有效回调，进程以非零状态结束，报告 `Reentrance login timed out.`。

用户随后提供浏览器错误：`APS_SEC_LGN_COMMON(002)`，SAP 将 `redirect-url` 参数判为不合法。该次地址包含 localhost、随机端口、`/redirect` 和 `state` 查询参数。此处不保存原始端口、关联值或完整回调 URL。

该次结论：默认 Fiori Tools 流程被 SAP 的回调地址校验阻止，但具体拒绝规则尚未查明；本地超时是未收到回调的后续结果。该次尝试没有票据兑换或 ADT 成功证据，也不能判定 ADT 访问权限。后续 `adt` 流程取得的成功不覆盖或改写此历史失败。

### 回调兼容性调查

- [SAP 官方回调实现](https://github.com/SAP/open-ux-tools/blob/main/packages/axios-extension/src/auth/reentrance-ticket/redirect.ts)使用固定 `/redirect`，不附加 `state`，也没有对应校验。本实现为满足计划中的登录请求关联保护增加了 `state`，其在目标租户的兼容性尚未成立。
- 已进行三个无凭据、不跟随跳转的公开端点 GET 对比：查询参数关联值、官方无查询参数形式、路径关联值。三者均返回 HTTP 200，均未匹配到该错误、Location 或票据。没有完成浏览器认证，因此这些结果**不能证明任何回调形式通过已认证的 SAP 校验**。
- 未找到公开的 FTO1 回调允许规则或可回传 nonce 的替代参数。不能根据一次错误断言所有 query/path 形式都不受支持，也不能认定删除 `state` 就能完成登录。
- 仅使用随机端口、一次性回调或本地 Cookie 不能等价替代当前请求关联保护。上述调查保留 `state` 校验，未据这些公开端点响应认定任何回调已获支持。

当时尚未查明的 FTO1 回调规则需要 SAP 或租户管理员解释，以下保留调查问题。这不是当前 ADT 实现的使用前提，也不表示该旧分支仍受支持：

> S/4HANA Cloud 的 `/sap/bc/sec/reentrance` 在 `scenario=FTO1` 下，对 localhost 随机端口的 `/redirect` 回调附加每次登录生成的 `state` 查询参数时，报告 `APS_SEC_LGN_COMMON(002)`、`redirect-url` 不合法。请确认允许的回调规则，以及受支持的请求关联方法（例如回传 state/nonce 或允许随机路径）。需保留登录请求关联验证。

### ADT 流程与回调边界适配

当时成功的 ADT 流程、以及当前统一后的实现，均使用 `/sap/bc/adt/core/http/reentranceticket` 登录端点和 `/adt/redirect` 本机回调路径，不发送 `scenario`；回调继续携带每次登录生成的 `state`，服务仍要求该值匹配后才消费票据。

初次 ADT 尝试已能重定向到本机，但浏览器显示 `No matching login request`。仅记录布尔值和计数的结构诊断显示：原始解析的 state 长度为 89，包含完整预期 nonce 前缀，包含第二个 `?`，ticket 数量为 1。未记录 nonce、ticket、Cookie、CSRF 或完整回调 URL。该结果表明完整的 64 位十六进制 nonce 得以保留，SAP 在追加其查询参数时使用了第二个 `?`，导致普通查询解析将后续参数并入 state。

修复仅在 ADT 指定回调路径下生效：确认 query 以 `?state=` 开始，完整 nonce 在预期长度的精确边界通过 `timingSafeEqual`，且紧随其后的字符为 `?` 后，仅将该边界的 `?` 改成 `&`。随后继续使用原有的单一 state、精确匹配、单一 ticket 和单次消费校验；没有改成仅校验前缀，也没有取消 state。适配后取得上面的历史真实只读成功结果；统一入口时继续保留该处理。

来源及证据范围：

- [SAP KBA 3259196](https://userapps.support.sap.com/sap/support/knowledge/en/3259196)提供 ADT reentrance-ticket 端点的官方依据。
- 已从 SAP 官方下载站取得 ADT 3.60.3 的 [destinations 插件](https://tools.hana.ondemand.com/latest/plugins/com.sap.adt.destinations_3.60.3.jar)和 [communication 插件](https://tools.hana.ondemand.com/latest/plugins/com.sap.adt.communication_3.60.3.jar)，通过静态分析核对端点、场景参数构造及 `/adt/redirect` 路径。
- 官方资料用于确认协议端点和回调路径；它们本身没有证明额外 `state` 查询参数的兼容性。目标租户的兼容性、边界适配、认证及 ADT 读取成功证据来自本次真实只读运行，不能推广为所有租户均已验证。

删除分支前的真实已验证范围为浏览器认证和回调、票据兑换、ADT discovery、完整系统信息及第二次 discovery 的会话复用。旧 Fiori Tools 分支的 `APS_SEC_LGN_COMMON(002)` 和超时仍保留为历史；当前版本不再包含该分支。SAP 写入与激活能力未测试，统一入口后也没有重跑真实登录。

旧回调已关闭；按照已批准计划，若租户拒绝带关联值的回调，不取消关联校验来绕过。运行方法见[中文登录说明](../../user-guide/REENTRANCE_TICKET_ZH.md)。

记录不包含 ticket、Cookie、CSRF、用户身份或完整回调 URL。
