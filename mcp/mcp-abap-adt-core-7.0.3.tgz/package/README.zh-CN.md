# <img src="logo.png" alt="mcp-abap-adt logo" width="36" align="absmiddle" /> mcp-abap-adt：ABAP 开发工具 (ADT) 的 MCP 网关

[English](README.md) | **中文**

`mcp-abap-adt` 是一个面向 SAP ECC / S/4HANA（on-premise）及 SAP BTP ABAP Cloud 系统的 **ABAP ADT MCP 服务器**。它让 AI Agent 通过 ADT 协议受控地访问真实的 ABAP 资源库，使分析与修改建立在系统真实数据之上，而不是猜测。

**两大主要工作流：**
- **深度 ABAP 分析**：where-used、对象元数据、资源库导航、对象结构、语义分析、依赖与影响探索。
- **高级 ABAP 开发**：RAP 与经典 ABAP 制品（类、接口、函数组/函数模块、程序、DDIC、CDS/视图/服务制品）的快速 CRUD 与迭代更新，全部经由 ADT 流程校验。

**核心能力：**
- **完整 CRUD**（非只读）：创建、读取、更新、删除 ABAP 制品
- 支持 **On-Premise（ECC/S/4HANA）**、**ABAP Cloud（BTP）** 与 **Legacy** 系统（BASIS < 7.50）
- **JWT/XSUAA**、**服务密钥**（destination 模式）、**basic**、**RFC** 等多种认证
- **S/4HANA Cloud 浏览器 SSO**：[Reentrance Ticket 登录](docs/user-guide/REENTRANCE_TICKET_ZH.md)，支持 stdio / HTTP / SSE，首次工具调用时按本机或远程入口登录
- 多种传输方式：**stdio**、**HTTP**、**SSE**
- 覆盖 ABAP 对象、元数据、传输请求、搜索的丰富工具面

> **增强说明**：本仓库在上游 v7.0.3 基础上增加了 **ATC 检查**、**Service Binding OData 发布**、**源码格式化**、**传输生命周期**等工具，并修复了多项 S/4HANA 上的问题（见[变更历史与增强](#变更历史与增强)）。这些新增工具尚未包含在 npm 发布版中，**须从飞书技能仓库安装**才可用。

## 目录

1. [安装](#安装)（完整版见 **[安装文档](docs/installation/INSTALL_ZH.md)**）
   - [选哪条路](#选哪条路)
   - [最短命令](#最短命令)
   - [填 env 并重启](#填-env-并重启)
   - [更新](#更新)
   - [HTTP / SSE 独立部署（进阶）](#http--sse-独立部署进阶)
2. [连接多个系统与切换](#连接多个系统与切换)
3. [env 文件详细配置](#env-文件详细配置)
4. [使用方法](#使用方法)
5. [工具分级（exposition）](#工具分级exposition)
6. [工具总览](#工具总览)
7. [常见问题与注意事项](#常见问题与注意事项)
8. [开发](#开发)
9. [变更历史与增强](#变更历史与增强)

## 安装

> **要连接 S/4HANA / ECC On-Premise？这是标准路径。** 你**不需要自己启动 server**，也**不要用 server 的 HTTP 模式**（那是[独立部署](#http--sse-独立部署进阶)，仅远程/独立场景用）：MCP 客户端（如 Claude Code）会自动以 **stdio** 方式把 server 作为本地进程拉起。

> 📖 **完整安装文档：[安装 mcp-abap-adt（中文）](docs/installation/INSTALL_ZH.md)** —— 三条来源 × 三种注册方式、env 字段、验证步骤、更新与排错，全在那一篇里。本节只给决策表和最短命令。

### 前置条件

- Node.js ≥ 22（本地验证使用 v24）
- 目标 SAP 系统开放 ADT 服务（SICF 节点 `/sap/bc/adt` 已激活），账号具备相应 ADT 权限
- 写操作（Create/Update/Delete/Activate）需要 `S_DEVELOP` 相应活动的授权
- 下表三条来源之一，对应的 CLI 已安装并登录

### 选哪条路

三条路的区别只有两件事：**依赖是否随包到位，注册是否自动完成。**

| | 来源 | 编译 | 运行时依赖 | 客户端注册 | 详见 |
|---|---|---|---|---|---|
| **H. Hi 平台** | `hi project init` | 不需要 | **已包含** | **自动**（Claude + Codex） | [路线 H](docs/installation/INSTALL_ZH.md#3-路线-hhi-平台hi-cli) |
| **A. 飞书技能仓库** | `install-skills.mjs` | 不需要 | 自己装 | 自己做 | [路线 A](docs/installation/INSTALL_ZH.md#4-路线-a飞书技能仓库) |
| **B. git clone** | 本仓库 | **需要** | 自己装 | 自己做 | [路线 B](docs/installation/INSTALL_ZH.md#5-路线-b从源码git-clone) |

两个容易踩的反差：

- **A 路装依赖要加 `--omit=dev`，B 路绝对不能加。** A 路拿到的是预构建包，只缺运行时依赖；B 路必须自己编译，而编译要用 `tsc`、`biome`，它们是 devDependencies。
- **H 路和 A 路都用不了 Kerberos 认证。** 两者依赖都以 `--ignore-scripts` 安装，`kerberos` 原生二进制不会下载（好处是包跨平台）。要 Kerberos 走 B 路。

### 最短命令

```bash
# H. Hi 平台 —— 解压 + 装依赖 + 注册，一步到位
hi project use <项目代码>
hi project init --root <绝对路径>/你的工程 --json
# 凭据填 <root>/.hi/mcp/mcp-abap-adt/.env（用户名密码被置空，其余保留）
# 记得把 .hi/ .hi-pack/ .mcp.json 加进该工程的 .gitignore

# A. 飞书技能仓库
node install-skills.mjs --skill mcp-abap-adt
cd <副本> && npm install --omit=dev --ignore-scripts

# B. git clone
git clone <仓库地址> mcp-abap-adt && cd mcp-abap-adt
npm install && npm run build          # 不要加 --omit=dev
```

**A 路和 B 路还需要注册到客户端**（H 路已自动完成），三选一：

```bash
# 方式 0：claude mcp add —— 最直接，只管 Claude Code，路径必须绝对
claude mcp add adt-dm2 -s user -e NODE_TLS_REJECT_UNAUTHORIZED=0   -- node /abs/path/bin/mcp-abap-adt.js      --env-path=/abs/path/dm2310.env --exposition=readonly,high

# 方式 A：install-mcp.js 全局 —— 同时写 Claude 和 Codex，env 按名字解析
node scripts/install-mcp.js --global --name=dev

# 方式 B：按工程 —— env 与 .mcp.json 都落在工程里
node scripts/install-mcp.js --target=/path/to/project --name=dev
```

三者的取舍见[注册方式怎么选](docs/installation/INSTALL_ZH.md#怎么选)。

### 填 env 并重启

env 字段见[env 文件详细配置](#env-文件详细配置)。**改完必须重启 MCP 客户端**——配置只在启动时读取。

重启后用 `GetSession` 验证：它返回 `server_version` / `build_timestamp` / `pid`，报告的是**实际被加载的那个构建**，不是磁盘上当前的文件。

### 更新

**重新取包，然后重启客户端。** server 只在启动时加载 `dist/`，重装对一个已经在跑的进程完全不可见。

```bash
hi project init --root <绝对路径> --json              # H
node install-skills.mjs --skill mcp-abap-adt         # A（之后重装一次依赖）
git pull && npm install && npm run build             # B
```

三条路都**不需要重新注册**，env 文件也都不会被动。详见[更新](docs/installation/INSTALL_ZH.md#11-更新)。

### HTTP / SSE 独立部署（进阶）

仅用于独立/远程部署，正常集成不需要：

```bash
node bin/mcp-abap-adt.js --transport=http --port=3000   # HTTP
node bin/mcp-abap-adt.js --transport=sse  --port=3001   # SSE
node bin/mcp-abap-adt.js --transport=stdio --env-path=/path/to/my.env   # 手动 stdio，仅调试
```


## 连接多个系统与切换

可以维护**多个 env 文件**（每个目标系统一个），按需切换或并列注册。

**1）每系统一个 env 文件。** 全局安装放标准 sessions 目录（`dev.env` / `qas.env` / …）；工程安装放工程 `env/` 目录。所有随系统变化的配置（含 `SAP_SYSTEM_TYPE`、`SAP_CONNECTION_TYPE`）都写进各自的 env，切文件即切换整套系统。

**2）并列注册多个条目（推荐多系统）**：`adt-dev`、`adt-qas`……各绑定自己的 env，使用时调用对应条目的工具即可。建议在客户端里停用暂不用的条目，减少工具数量与误操作面。每个系统跑一次安装脚本即可：

```bash
node scripts/install-mcp.js --global --name=qas          # 全局
node scripts/install-mcp.js --target=<工程> --name=qas   # 工程级
```

**3）或就地切换单个条目**：改条目的 `--env`（全局）或 `--env-path`（工程），然后**重启 MCP 客户端**（server 启动后即绑定其 env，不重启不生效）。

> **全局 vs 工程怎么选**：个人多工程共用、不想重复配 → 全局（`--env`，写在 `~/.claude.json`）；工程强绑定某套系统、配置随仓库走 → 工程（`--env-path`，写在工程 `.mcp.json`）。两者可并存，都会被 Claude Code 加载。

## env 文件详细配置

每个目标系统一个 `.env` 文件（**切勿提交进版本库**，含凭据）。只支持**整行注释**（以 `#` 开头），不支持行内注释。

### 通用字段

| 字段 | 说明 |
|---|---|
| `SAP_URL` | SAP ABAP 应用服务器地址 `http(s)://host:port`（启用 SSL 用 `https`）|
| `SAP_CLIENT` | 客户端（集团）号，如 `100` |
| `SAP_LANGUAGE` | 登录语言，如 `en`。**这就是本服务创建的所有对象的原始语言**（它会作为 `sap-language` 附加到每个请求，并同时写入载荷的 `adtcore:masterLanguage`，两者始终一致）。默认 `EN`。如果团队还会在 SE11/SE80 里用另一种登录语言建对象，请把这里设成同一种语言——否则同一个包里的对象原始语言会不一致，以后做翻译会乱。 |
| `SAP_SYSTEM_TYPE` | `onprem` / `cloud` / `legacy` |
| `SAP_CONNECTION_TYPE` | `http`（默认）或 `rfc`；指 server 连 SAP 的方式，**与 server 是否 HTTP 模式无关** |
| `SAP_AUTH_TYPE` | `basic` / `jwt` / `certificate` / `kerberos` / [`reentrance-ticket`](docs/user-guide/REENTRANCE_TICKET_ZH.md)（stdio / HTTP / SSE）|
| `NODE_TLS_REJECT_UNAUTHORIZED` | 自签名证书场景设 `0`（仅受信内网）|

> **`SAP_USERNAME` 大小写必须与 USR02 一致（通常大写）。** 登录不区分大小写，但创建对象时该值会**原样**作为「负责人」提交，小写会导致 `PAK049`（无效用户）错误。

### 认证方式

**Basic（on-premise 常用）：**
```bash
SAP_AUTH_TYPE=basic
SAP_USERNAME=YOUR_USER
SAP_PASSWORD=your-password
```

**JWT（SAP BTP）：**
```bash
SAP_AUTH_TYPE=jwt
SAP_JWT_TOKEN=your-jwt-token
```

**客户端证书 mTLS（仅 on-prem HTTP）：** 无需用户名/密码。
```bash
SAP_AUTH_TYPE=certificate
SAP_CERT_PATH=/path/to/client.crt      # PEM：证书
SAP_CERT_KEY_PATH=/path/to/client.key  # PEM：私钥
# 或 PKCS#12（与 PEM 二选一）：
# SAP_CERT_PFX_PATH=/path/to/client.pfx
# SAP_CERT_PASSPHRASE=your-passphrase
```

**Kerberos / SPNEGO（仅 on-prem HTTP）：** 需先 `kinit` 取得票据，并安装 `kerberos` npm 包（`npm i kerberos`）。
```bash
SAP_AUTH_TYPE=kerberos
# 可选：显式 SPN（默认 HTTP@<host>）
# SAP_KERBEROS_SPN=HTTP@mysaphost.corp.example
```

**RFC（legacy，BASIS < 7.50）：** 需 SAP NW RFC SDK，见 [RFC Setup Guide](docs/installation/RFC_SETUP.md)。
```bash
SAP_AUTH_TYPE=basic
SAP_CONNECTION_TYPE=rfc
SAP_USERNAME=YOUR_USER
SAP_PASSWORD=your-password
```

> 证书 / Kerberos 通过完整单测但**尚未在真实系统验证**，欢迎试用并反馈。

### Destination（服务密钥）模式

把服务密钥 JSON 放入标准目录，用文件名（不含扩展名）作为 destination，用 `--mcp=<destination>` 选择：
- Unix：`~/.config/mcp-abap-adt/service-keys/<destination>.json`
- Windows：`%USERPROFILE%\Documents\mcp-abap-adt\service-keys\<destination>.json`

```bash
mcp-abap-adt --transport=stdio --mcp=TRIAL
```

也可由服务密钥生成 env：`npm i -g @mcp-abap-adt/connection` 后执行 `mcp-auth auth -k path/to/service-key.json`。

## 使用方法

工具的输入输出均为 JSON。以下按典型场景给出调用示例（以 MCP 工具调用的参数形式表示）。

### 读取与分析（readonly，安全）

```jsonc
// 查找对象
SearchObject        { "query": "YI_MFGR001*" }
// 读取 CDS 视图源码
GetView             { "view_name": "YI_MFGR001_001" }
// 包内容
GetPackageContents  { "package_name": "YMFGR001" }
// 影响分析
GetWhereUsed        { "object_name": "YI_MFGR001_001", "object_type": "DDLS/DF" }
// 读表数据 / 自由 SQL
GetTableContents    { "table_name": "T000", "max_rows": 10 }
GetSqlQuery         { "sql_query": "SELECT COUNT(*) FROM mara" }
```

### 创建与修改（high）

```jsonc
// 1. 创建传输请求（可传 workbench 请求下的任务号）
CreateTransport   { "description": "MFGR001 RAP objects", "transport_type": "workbench" }

// 2. 创建 CDS 视图（注意：transport_request 必须传"任务"号，不是父请求号）
CreateView        { "view_name": "YI_MFGR001_003", "package_name": "YMFGR001",
                    "transport_request": "ABCK900001", "ddl_source": "define view entity ..." }

// 3. 语法检查（可校验未保存的新代码）
CheckView         { "view_name": "YI_MFGR001_003", "ddl_source": "..." }

// 4. 激活
ActivateView      { "view_name": "YI_MFGR001_003" }
```

### RAP 完整部署链（本克隆）

```text
CreateView(接口视图/消费视图) → ActivateView
→ CreateMetadataExtension → ActivateMetadataExtension
→ CreateServiceDefinition → ActivateServiceDefinition
→ CreateServiceBinding → ActivateServiceBinding
→ PublishServiceBinding        ← 🆕 真正发布 OData 服务端点
→ RunAtc                       ← 🆕 ATC 质量检查
→ RunUnitTest                  ← ABAP Unit
```

### 一键生成 RAP 服务（生成器，🆕）

上面是逐个对象手工搭建；若只是要从一张已有的数据库表快速拉起标准 RAP 服务，
`GenerateRepoObjects` 一次调用即可（内部走 ADT 仓库生成器）：

```jsonc
// 完整 OData V4 UI 服务：根 CDS + BDEF + 行为实现类 + 草稿表
//                        + 服务投影 + 服务定义 + Service Binding + 元数据扩展
GenerateRepoObjects {
  "type": "uiservice",
  "reference_object_name": "ZLEAVE_R2",       // 源数据库表
  "package": "ZLEAVE",
  "transport_request": "ABCK900001",          // $TMP/本地包可留空
  "cds_name": "ZR_LEAVE_R23",
  "behavior_implementation_class": "ZBP_LEAVE_R23",
  "draft_table": "ZDRAFT_LEAVE_R23",
  "service_projection_name": "ZC_LEAVE_R23",
  "service_definition_name": "ZUI_LEAVE_R2_O43",
  "service_binding_name": "ZUI_LEAVE_R2_O43"
}
// → { success, type, http_status, message,
//     generated_objects: [ { name, type, uri, meta }, ... ],
//     service_binding:   { uri, http_status, payload } }   ← 回读的 SRVB
// 之后用 PublishServiceBinding 发布端点即可对外消费

// Web API 变体（无 UI 专属内容、无草稿表）：type = "webapiservice"
// 定制表的 Fiori 维护对象（SM30/SM34 替代）：
GenerateRepoObjects {
  "type": "smbc",
  "reference_object_name": "ZCUST_TABLE",
  "package": "ZLEAVE",
  "maintenance_object_name": "ZMO_LEAVE_R2"
}
```

> ⚠️ 该工具目前仅有单测覆盖，实机冒烟测试默认关闭（见"变更历史与增强"末尾的验证说明）。

### ATC 检查

```jsonc
// 一步式：多对象一次运行（省时），返回 worklist_id 供重读
RunAtc {
  "objects": [
    { "object_name": "YI_MFGR001_001", "object_type": "view" },
    { "object_name": "YMFGR001",       "object_type": "package" }
  ],
  "max_results": 200
}
// → { check_variant, worklist_id, findings_by_priority, findings: [
//      { priority, check_title, message_title, location, quickfix_info, link, ... } ] }

// 查询系统默认检查变式与豁免原因
GetAtcCustomizing { }

// 免重跑重读结果
GetAtcWorklist    { "worklist_id": "<RunAtc 返回值>" }
```

### Service Binding 发布

```jsonc
// OData V2（如 UI_V2 绑定）
PublishServiceBinding   { "binding_name": "YUI_MFGR001_001", "odata_version": "v2" }
// OData V4
PublishServiceBinding   { "binding_name": "YUI_MFGR001_001", "odata_version": "v4" }
// 取消发布
UnpublishServiceBinding { "binding_name": "YUI_MFGR001_001", "odata_version": "v2" }
// → { success, severity, short_text, long_text }（SAP StatusMessage 原文）
```

### 单元测试

```jsonc
RunUnitTest        { "object_name": "YCL_MY_CLASS", "object_type": "class" }
GetUnitTestResult  { "run_id": "..." }
```

## 工具分级（exposition）

通过 `--exposition` 控制暴露哪些工具组（`search` 与 `system` 组始终包含）：

| 组 | 内容 | 场景 |
|---|---|---|
| `readonly` | 只读操作（源码、结构、schema、搜索）| 生产 / 纯分析 |
| `high` | 高级写操作（对象 CRUD、包、传输）| 开发（推荐 `readonly,high`）|
| `low` | 低级直接操作（锁、原始请求等，危险）| 测试/管理，与 `high` 互斥 |
| `compact` | 精简门面：27 个统一入口，含对象 CRUD 与分析/搜索/运行时 | 上下文吃紧；只能单独使用 |

合法组合：`[readonly]`、`[readonly, high]`、`[readonly, low]`、`[high]`、`[low]`、`[compact]`。

## 工具总览

共 **368 个工具**（`readonly,high` 档位下暴露 241 个：只读 77 + 高级 164）。绝大多数对象类型都配有一整套生命周期方法：`Create`（创建）/ `Get`（读取）/ `Update`（更新）/ `Delete`（删除）/ `Activate`（激活）/ `Check`（语法检查）。下面按功能领域折叠列出**每个方法的名称与功能**（点击标题展开）。🆕 = 本克隆相对上游新增/吸收。

<details>
<summary><b>对象 CRUD 与生命周期</b></summary>

**DDIC —— 域 / 数据元素 / 表 / 结构**
- `CreateDomain` / `GetDomain` / `UpdateDomain` / `DeleteDomain` / `ActivateDomain` / `CheckDomain` —— 域：创建/读取/更新/删除/激活/检查（含数据类型、长度、固定值）
- `CreateDataElement` / `GetDataElement` / `UpdateDataElement` / `DeleteDataElement` / `ActivateDataElement` / `CheckDataElement` —— 数据元素（基于域或内置类型 + 字段标签）
- `CreateTable` / `GetTable` / `UpdateTable` / `DeleteTable` / `ActivateTable` / `CheckTable` —— 透明表（字段/键/技术设置；数据预览用 `GetTableContents`）
- `CreateStructure` / `GetStructure` / `UpdateStructure` / `DeleteStructure` / `ActivateStructure` / `CheckStructure` —— 结构（组件 + include）

**经典 ABAP —— 类 / 接口 / 程序 / 函数**
- `CreateClass` / `GetClass` / `UpdateClass` / `DeleteClass` / `ActivateClass` / `CheckClass` —— 全局类
- 类的局部包含：`GetLocalDefinitions` / `UpdateLocalDefinitions` / `DeleteLocalDefinitions`（局部定义）、`GetLocalTypes` / `UpdateLocalTypes` / `DeleteLocalTypes`（局部类型/实现）、`GetLocalMacros` / `UpdateLocalMacros` / `DeleteLocalMacros`（宏）、`GetLocalTestClass` / `UpdateLocalTestClass` / `DeleteLocalTestClass`（局部测试类）
- `CreateInterface` / `GetInterface` / `UpdateInterface` / `DeleteInterface` / `ActivateInterface` / `CheckInterface` —— 全局接口
- `CreateProgram` / `GetProgram` / `UpdateProgram` / `DeleteProgram` / `ActivateProgram` / `CheckProgram` —— 报表程序（仅 on-prem / legacy）
- `GetInclude` —— 读取 include 源码；`GetIncludesList` —— 递归列出 include
- `CreateFunctionGroup` / `GetFunctionGroup` / `UpdateFunctionGroup` / `DeleteFunctionGroup` / `ActivateFunctionGroup` / `CheckFunctionGroup` —— 函数组
- `CreateFunctionModule` / `GetFunctionModule` / `UpdateFunctionModule` / `DeleteFunctionModule` / `ActivateFunctionModule` / `CheckFunctionModule` —— 函数模块

**CDS / RAP**
- `CreateView` / `GetView` / `UpdateView` / `DeleteView` / `ActivateView` / `CheckView` —— CDS 视图（DDLS）/ 经典视图
- `CreateMetadataExtension` / `GetMetadataExtension` / `UpdateMetadataExtension` / `DeleteMetadataExtension` / `ActivateMetadataExtension` / `CheckMetadataExtension` —— 元数据扩展（DDLX）
- `CreateBehaviorDefinition` / `GetBehaviorDefinition` / `UpdateBehaviorDefinition` / `DeleteBehaviorDefinition` / `ActivateBehaviorDefinition` / `CheckBehaviorDefinition` —— 行为定义（BDEF；Managed/Unmanaged/Abstract/Projection）
- `CreateBehaviorImplementation` / `GetBehaviorImplementation` / `UpdateBehaviorImplementation` / `DeleteBehaviorImplementation` —— 行为实现类（behavior pool）
- `CreateServiceDefinition` / `GetServiceDefinition` / `UpdateServiceDefinition` / `DeleteServiceDefinition` / `ActivateServiceDefinition` / `CheckServiceDefinition` —— 服务定义（SRVD）
- `CreateServiceBinding` / `GetServiceBinding` / `UpdateServiceBinding` / `DeleteServiceBinding` / `ActivateServiceBinding` —— 服务绑定（SRVB；OData 发布见「Service Binding 发布」）
- `CreateAccessControl` / `GetAccessControl` / `UpdateAccessControl` / `DeleteAccessControl` / `ActivateAccessControl` / `CheckAccessControl` 🆕 —— CDS **访问控制**（DCL / DCLS）：CDS 实体之上的授权层（`define role … { grant select on … }`）。`CreateAccessControl` 可在一次调用里内联写入角色源码并激活；`CheckAccessControl` 支持在写入之前先对**草稿**做语法检查

**其他仓库对象 🆕**
- `CreateXslt` / `GetXslt` / `UpdateXslt` / `DeleteXslt` / `ActivateXslt` —— 转换（XSLT/ST；源码型）
- `CreateMessageClass` / `GetMessageClass` / `UpdateMessageClass` / `DeleteMessageClass` —— 消息类（MSAG）；`UpdateMessageClass` 设置完整消息列表（消息号 + 短文本）
- `CreateLockObject` / `GetLockObject` / `UpdateLockObject` / `DeleteLockObject` / `ActivateLockObject` —— 锁对象（ENQU；主表 + 锁模式；激活时生成 ENQUEUE_/DEQUEUE_ 函数模块）

**包 / 会话 / 批量**
- `CreatePackage` —— 创建包（支持真顶层包）；`GetPackage` —— 读取包元数据；`CheckPackage` —— 检查；`DeletePackage` 🆕 —— 删除**空**包（SAP 的拒绝原因原样转达；没有 TADIR/TDEVC 记录的孤儿包 ADT 删不掉，需 SE21 处理）
- `GetPackageContents` —— 包内对象平铺列表；`GetPackageTree` —— 包层级树（含子包）
- `ActivateObjects` —— 批量激活任意对象（如 域+数据元素+表 一并激活）
- `GetInactiveObjects` —— 列出待激活的未激活对象
- `GetSession` —— 获取/复用 ADT 会话（供低层操作串联）

</details>

<details>
<summary><b>仓库生成器 🆕</b></summary>

- `GenerateRepoObjects` 🆕 —— 驱动 SAP ADT **仓库生成器**：一次调用即可把一张数据库表变成一整套已生成的对象。三种生成类型：
  - `uiservice` —— 完整的 **RAP OData V4 UI 服务**：根 CDS 视图 + 行为定义（BDEF）+ 行为实现类 + 草稿表 + 服务投影 + 服务定义 + Service Binding + 元数据扩展
  - `webapiservice` —— 同样的 RAP 栈，但生成 **OData Web API** 服务（无 UI 专属内容，无草稿表）
  - `smbc` —— 针对定制表的 **Fiori 维护对象**（SM30/SM34 的替代）
- 主要参数：`type`、`reference_object_name`（源表）、`package`，以及各类型专属名称（`cds_name`、`behavior_implementation_class`、`service_projection_name`、`service_definition_name`、`service_binding_name`、`draft_table`、`maintenance_object_name`）；可选 `transport_request`、`master_language`、`description`、`service_binding_type`（`OData V4 - UI` / `OData V4` / `OData V2 - UI` / `OData V2`）。
- 返回生成对象的引用列表；对 `uiservice` / `webapiservice` 还会**回读刚生成的 Service Binding** 一并返回，使其状态在同一次调用中即可确认。随后用 `PublishServiceBinding` 发布即可对外消费。

</details>

<details>
<summary><b>搜索、导航与分析</b></summary>

- `SearchObject` —— 按名称/通配符搜索对象
- `SearchSource` —— 源码全文搜索
- `GetWhereUsed` —— where-used 引用/影响分析
- `DescribeByList` —— 批量获取对象元信息
- `GetObjectStructure` —— 对象结构（方法/属性/组件树）；`GetObjectInfo` —— 对象基本元数据
- `GetObjectsList` —— 列出对象；`GetObjectsByType` —— 按对象类型列出
- `GetTransaction` —— 事务码信息
- `GetEnhancements` —— 对象的增强清单；`GetEnhancementImpl` —— 增强实现源码；`GetEnhancementSpot` —— 增强 spot
- `GetAbapAST` —— 抽象语法树；`GetAbapSemanticAnalysis` —— 语义分析；`GetAbapSystemSymbols` —— 系统符号
- `GetTypeInfo` —— 类型信息；`GetAdtTypes` —— ADT 对象类型清单
- `GetObjectRevisions` 🆕 —— 对象版本历史（版本/作者/日期）
- `GetAbapDocumentation` 🆕 —— 某源码位置关键字/元素的 ABAP 文档（HTML）
- 低层导航：`GetNodeStructureLow` —— 节点结构；`GetObjectStructureLow` —— 原始结构；`GetVirtualFoldersLow` —— 虚拟文件夹；`GetObjectNodeFromCache` —— 读缓存节点

</details>

<details>
<summary><b>质量与测试</b></summary>

- 语法检查：各对象的 `Check<对象>`（见上表，如 `CheckClass` / `CheckView` …）
- `RunAtc` 🆕 —— 一步式 ATC：变式解析→worklist→运行→findings（含 `quickfix_info`/`link`/`location`），支持多对象单次运行，返回 `worklist_id`
- `GetAtcWorklist` 🆕 —— 按 `worklist_id` 重读 findings（不重跑）；`GetAtcCustomizing` 🆕 —— 系统默认检查变式与豁免原因
- `GetFixProposals` 🆕 —— 列出某位置的快速修复建议；`GetFixEdits` 🆕 —— 计算选定快速修复的编辑增量（只算不写）
- ABAP Unit：`CreateUnitTest` / `GetUnitTest` / `UpdateUnitTest` / `DeleteUnitTest`、`RunUnitTest`（运行）/ `GetUnitTestResult`（结果）/ `GetUnitTestStatus`（状态）
- CDS 测试：`CreateCdsUnitTest` / `GetCdsUnitTest` / `UpdateCdsUnitTest` / `DeleteCdsUnitTest`、`GetCdsUnitTestResult` / `GetCdsUnitTestStatus`

</details>

<details>
<summary><b>源码格式化 🆕</b></summary>

- `PrettyPrintSource` 🆕 —— 按系统 pretty-printer 设置格式化 ABAP 源码
- `GetPrettyPrinterSettings` 🆕 —— 读取 pretty-printer 设置（缩进、关键字大小写）
- `SetPrettyPrinterSettings` 🆕 —— 修改系统级 pretty-printer 设置

</details>

<details>
<summary><b>Service Binding 发布</b></summary>

- `ValidateServiceBinding` —— 校验服务绑定
- `ListServiceBindingTypes` —— 列出可用绑定类型
- `PublishServiceBinding` 🆕 —— 发布 OData 服务端点（V2/V4），`ActivateServiceBinding` 之后使服务真正可访问
- `UnpublishServiceBinding` 🆕 —— 取消发布（V2/V4）

</details>

<details>
<summary><b>传输（CTS）</b></summary>

- `CreateTransport` —— 创建传输请求；`GetTransport` —— 查询；`ListTransports` —— 列出用户传输
- `ReleaseTransport` 🆕 —— 释放（可选忽略锁/ATC）；`DeleteTransport` 🆕 —— 删除未释放请求
- `SetTransportOwner` 🆕 —— 改所有者；`AddTransportUser` 🆕 —— 为请求添加用户任务；`MergeTransport` 🆕 —— 把一个请求合并到另一个请求下（SE10 合并请求），合并后回读校验

</details>

<details>
<summary><b>数据与运行时诊断</b></summary>

- `GetTableContents` —— 表数据预览；`GetSqlQuery` —— 自由 SQL 查询（ADT Data Preview）
- 执行：`RuntimeRunClass` —— 运行类；`RuntimeRunProgram` —— 运行程序
- Profiler：`RuntimeRunClassWithProfiling` / `RuntimeRunProgramWithProfiling`（带性能分析执行）、`RuntimeCreateProfilerTraceParameters` / `RuntimeListProfilerTraceFiles` / `RuntimeGetProfilerTraceData` / `RuntimeAnalyzeProfilerTrace`（trace 参数/列表/数据/分析）
- 诊断：`RuntimeGetDumpById` —— 按 ID 取 dump；`RuntimeGetGatewayErrorLog` —— 网关错误日志；`RuntimeListSystemMessages` —— SM02 系统消息；`RuntimeListFeeds` —— feed 列表

</details>

<details>
<summary><b>Compact 门面（<code>--exposition=compact</code>）</b></summary>

- **27 个工具**，按 `object_type` 参数路由，用于极简工具面场景（schema 约 2,500 token，对比 `readonly,high` 的约 57,000）。只能单独使用。
- 对象生命周期：`HandlerCreate` / `HandlerGet` / `HandlerUpdate` / `HandlerDelete` / `HandlerActivate` / `HandlerCheckRun` / `HandlerLock` / `HandlerUnlock` / `HandlerValidate`，另含单元测试、性能分析与 dump。
- 🆕 分析集：`HandlerQuery`（SQL / 表数据）、`HandlerSearch`（对象 / 源码 / where-used）、`HandlerAtc`（执行 / 工作清单 / 客制化）、`HandlerRuntime`（跑程序 / 类）、`HandlerInactiveObjects`（未激活对象清扫）以及 `CallIcfService`。没有这一组，门面完全够不到分析、搜索与运行时这三类。

</details>

> 🆕 已在 DM2 实机验证的有：`PrettyPrintSource`、`GetPrettyPrinterSettings`、`GetObjectRevisions`、`GetAbapDocumentation`、`RunAtc`（详见[变更历史与增强](#变更历史与增强)）。

**逐个工具的完整清单与参数**见 `docs/user-guide/AVAILABLE_TOOLS.md`（及分档位的 `AVAILABLE_TOOLS_READONLY/HIGH/LOW/COMPACT.md`），可用 `npm run docs:tools` 重新生成。

## 常见问题与注意事项

| 现象 | 原因与处理 |
|---|---|
| 修改源码后工具行为没变 / 新工具不出现 | MCP 进程启动时加载 `dist/`。先 `npm run build:fast`，再**重启 MCP 客户端** |
| `CreatePackage` 报 `PAK049`（无效用户）| env 中 `SAP_USERNAME` 大小写与 USR02 不一致（改成大写后重启）；或该用户在 SU01 中无有效期 |
| 创建对象返回 HTTP 400（传输相关）| `transport_request` 传了**父请求**号 —— 必须传其下的**任务**号 |
| 创建对象返回 409 但对象不存在 | 不是缓存问题（本服务器无对象缓存，409 来自 SAP 实时响应）。检查：包是否允许添加对象（`isAddingObjectsAllowed`）、用户是否有 `S_DEVELOP` ACTVT=01 对应对象类型 |
| CDS 的 validate 400 / UpdateView 报 PUT 不支持 | 目标系统 ADT DDL 端点（SICF `/sap/bc/adt/ddic/ddl`）配置/版本问题，需 Basis 处理 |
| 自签证书 TLS 失败 | env 或 `.mcp.json` 中设置 `NODE_TLS_REJECT_UNAUTHORIZED=0`（仅限受信内网）|
| ABAP Cloud 无法预览表数据 | BTP 后端策略限制 ADT 数据预览，属预期行为 |

## 开发

```bash
npm run build        # biome 检查 + tsc 完整构建
npm run build:fast   # 仅 tsc 增量构建
npm run test:unit    # 单元测试；跳过 SAP integration globalSetup
npm run docs:tools   # 重新生成工具文档（docs/user-guide/AVAILABLE_TOOLS_*.md）
npm run lint         # biome 检查并自动修复
```

新增工具的步骤：在 `src/handlers/<domain>/<readonly|high|low>/` 创建 handler（导出 `TOOL_DEFINITION` 与处理函数）→ 在 `src/lib/handlers/groups/` 对应 Group 注册 → 重新构建。详见 `docs/user-guide/HANDLERS_MANAGEMENT.md`。

## 变更历史与增强

本仓库基于上游 fr0ster v7.0.3，独立维护，增加了一批工具并修复了若干在真实 S/4HANA（SAP_BASIS 7.56，DM2）上暴露的问题。以下均已 live 验证。

### 新增/吸收的工具

- **ATC 检查**：`RunAtc`（一步式、多对象、含 quickfix_info/link/location）、`GetAtcWorklist`、`GetAtcCustomizing`。**刻意未**实现 ATC 豁免申请（`atcRequestExemption` 等）—— 抑制发现应由人决定，不交给 Agent。
- **快速修复**：`GetFixProposals`、`GetFixEdits`（只计算编辑增量，不写源码）。
- **Service Binding 发布**：`PublishServiceBinding` / `UnpublishServiceBinding`（OData V2/V4），补齐 `ActivateServiceBinding` 之后"真正可访问"的一步。
- **仓库生成器**：`GenerateRepoObjects` —— 驱动 ADT 仓库生成器（`uiservice` / `webapiservice` / `smbc`），从一张数据库表脚手架出整套 RAP OData 服务或 Fiori 维护对象。`@mcp-abap-adt/adt-clients` 无对应封装，故直接访问 `/sap/bc/adt/**/generators/<type>`（与传输生命周期工具相同的 direct-REST 模式）。对 `uiservice` / `webapiservice` 会在同一次调用里回读生成的 Service Binding；该 SRVB GET 在 `Accept` 中**同时**声明 v1 与 v2 两种 SRVB 媒体类型（缺任一 SAP 会返回 406）。已有单测覆盖；实机冒烟测试**默认关闭**（准备好源表后在 `tests/test-config.yaml` 中开启 `generate_repo_objects`）—— 见下方验证说明。
- **源码格式化**：`PrettyPrintSource`、`GetPrettyPrinterSettings`、`SetPrettyPrinterSettings`。
- **版本/文档**：`GetObjectRevisions`、`GetAbapDocumentation`。
- **传输生命周期**：`ReleaseTransport`、`DeleteTransport`、`SetTransportOwner`、`AddTransportUser`（补齐原有的 `CreateTransport` / `ListTransports`）。
- **消息类 / 锁对象 / 转换 的完整 CRUD** 🆕 —— 三类此前没有创建工具（`@mcp-abap-adt/adt-clients` 也无封装）。实机 `/sap/bc/adt/discovery` 暴露了这三类的创建集合，故用直接 `makeAdtRequest` 实现：
  - **转换（XSLT）**：`CreateXslt`、`GetXslt`、`UpdateXslt`、`DeleteXslt`、`ActivateXslt`
  - **消息类（MSAG）**：`CreateMessageClass`、`GetMessageClass`、`UpdateMessageClass`（**UPSERT 语义**——省略的消息会保留，不会被删除）、`DeleteMessageClass`、`AddMessage`、`UpdateMessage`
  - **锁对象（ENQU）**：`CreateLockObject`、`GetLockObject`、`UpdateLockObject`、`DeleteLockObject`、`ActivateLockObject`（激活时自动生成 ENQUEUE_/DEQUEUE_ 函数模块）
- **构建标识** 🆕 —— `GetSession` 返回 `server_version`、`build_timestamp`、`started_at`、`pid`，每条错误信息末尾也带 `[mcp-abap-adt <版本>, built <时间>, pid <进程号>]`。时间戳在进程加载时冻结、不是每次调用读文件：否则服务器运行中重新构建，工具就会声称一个它并没有在跑的版本。反馈问题时请连它一起贴。
- **对象名称长度守卫** 🆕 —— `Create*` 在名称超出 DDIC/OO 上限时快速失败（表/视图 16、多数类型 30、function_group 26、program 40、message_class 20），因为 SAP 会静默截断超长名并随后误报「已存在」。

实现参考 [marcellourbani/abap-adt-api](https://github.com/marcellourbani/abap-adt-api)。

### 关键修复

- **P1 登录语言不匹配**：连接层从不发送 `sap-language`，导致登录语言 = 账号默认（如 ZH）而 payload 声明 EN，凡带描述的创建全部失败（CreateView 400、CreateDataElement「缺少描述」等）。修复：在连接层为每个请求注入 `sap-language == SAP_LANGUAGE`，登录语言与声明语言按构造一致。已在 12 种对象类型验证。
- **P2 GetWhereUsed 全类型 404**：底层 `getWhereUsedList` 会先做 `/usageReferences/scope` 预检，S/4 7.56 不暴露该端点。修复：改为像 Eclipse 一样单次直接 POST（空 `<affectedObjects/>` + 默认 scope）。
- **P3 `total_rows: 0` 误导**：SAP 不请求计数时该值本就为 0（非 bug）。GetSqlQuery / GetTableContents 增加 `returned_rows`（真实行数）。
- **P4 GetPackageContents/Tree 描述错位**：遗留 stateful 会话下 `/repository/nodestructure` 会把某节点描述从上一次节点串过来。修复：取节点时显式发 `x-sap-adt-sessiontype: stateless` 头以终止遗留会话（`setSessionType('stateless')` 只是省略头、不足以清除）。
- **P6 CreatePackage 真顶层包**：adt-clients `AdtPackage` 在联网前硬性抛「Super package is required」。修复：无父包且非 structure 时走 direct-POST 绕过（复刻底层校验 + 建包，空 `<pak:superPackage/>`，注入 `responsible`/`masterSystem`），继承 P1 语言注入。
- **域 创建/更新**：底层用正则 patch 只能替换已存在的元素，裸建的域会丢失 datatype/length/decimals（decimals=0 也被当假值跳过）。修复：`writeDomainContent` 读取→解析→插入 `<doma:content>` 子树→写回。
- **结构 创建**：`CreateStructure` 曾忽略 `fields`、建出空结构。修复：由字段/包含生成 DDL 并写入。
- **CDS 创建**：`CreateView` 改为直接 POST `/ddic/ddl/sources` 并带 `sap-language`，解决语言等值校验（`DDIC_ADT_DDLS/016`）。
- **创建前存在性预检（Plan A）**：8 个 Create* 处理器在建对象前先解释 validate 结果，重名则语言无关地快速失败（通过异常 `type` id 判定，不依赖本地化文本），避免半创建对象。

> ⚠️ 尚未在真实系统验证：证书 / Kerberos 认证、`SetPrettyPrinterSettings`，以及 `GenerateRepoObjects`（仅有单测覆盖；其集成冒烟测试**默认关闭**，需在 `tests/test-config.yaml` 中启用 `generate_repo_objects` 用例并指向一张真实源表才会执行）。

## 文档与致谢

- 完整文档索引：[docs/README.md](docs/README.md)（认证、客户端配置、YAML 配置、架构等）
- 上游项目：[fr0ster/mcp-abap-adt](https://github.com/fr0ster/mcp-abap-adt)，最初灵感来自 [mario-andreschak/mcp-abap-adt](https://github.com/mario-andreschak/mcp-abap-adt)
- ATC / Service Binding 发布的实现参考：[marcellourbani/abap-adt-api](https://github.com/marcellourbani/abap-adt-api)
